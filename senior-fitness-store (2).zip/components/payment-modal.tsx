"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/hooks/use-toast"
import { CreditCard, Smartphone, Building, X, Loader2 } from "lucide-react"

interface PaymentModalProps {
  isOpen: boolean
  onClose: () => void
  product: {
    id: number
    name: string
    price: number
    image?: string
  }
  quantity: number
}

export function PaymentModal({ isOpen, onClose, product, quantity }: PaymentModalProps) {
  const { toast } = useToast()
  const [isProcessing, setIsProcessing] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState("")
  const [tossClientKey, setTossClientKey] = useState<string | null>(null)

  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    phone: "",
    email: "",
  })

  const [shippingInfo, setShippingInfo] = useState({
    recipient_name: "",
    recipient_phone: "",
    address: "",
    detailed_address: "",
    postal_code: "",
    delivery_request: "",
  })

  const totalAmount = product.price * quantity

  useEffect(() => {
    if (isOpen) {
      // 모달이 열릴 때마다 상태 초기화
      setPaymentMethod("")
      setCustomerInfo({
        name: "",
        phone: "",
        email: "",
      })
      setShippingInfo({
        recipient_name: "",
        recipient_phone: "",
        address: "",
        detailed_address: "",
        postal_code: "",
        delivery_request: "",
      })
      setIsProcessing(false)

      // Fetch Toss client key safely from the server
      fetch("/api/config/toss")
        .then((res) => res.json())
        .then((data) => setTossClientKey(data.clientKey as string))
        .catch((err) => {
          console.error("Failed to load Toss client key:", err)
          setTossClientKey(null)
        })
    }
  }, [isOpen])

  const handlePayment = async () => {
    if (!paymentMethod) {
      toast({
        title: "오류",
        description: "결제 방법을 선택해주세요.",
        variant: "destructive",
      })
      return
    }

    if (
      !customerInfo.name ||
      !customerInfo.phone ||
      !shippingInfo.recipient_name ||
      !shippingInfo.recipient_phone ||
      !shippingInfo.address
    ) {
      toast({
        title: "오류",
        description: "필수 정보를 모두 입력해주세요.",
        variant: "destructive",
      })
      return
    }

    setIsProcessing(true)

    try {
      // 주문 생성
      const orderResponse = await fetch("/api/orders/create", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          product_id: product.id,
          quantity,
          total_amount: totalAmount,
          payment_method: paymentMethod,
          customer_info: {
            name: customerInfo.name,
            phone1: customerInfo.phone,
            address: shippingInfo.address,
            email: customerInfo.email,
          },
          shipping_info: shippingInfo,
        }),
      })

      const orderResult = await orderResponse.json()

      if (orderResult.success) {
        // 결제 방법에 따른 처리
        if (paymentMethod === "toss") {
          await handleTossPayment(orderResult.order_id, orderResult.payment_id)
        } else if (paymentMethod === "kakaopay") {
          await handleKakaoPayment(orderResult.order_id, orderResult.payment_id)
        } else if (paymentMethod === "bank_transfer") {
          await handleBankTransfer(orderResult.order_id)
        }
      } else {
        throw new Error(orderResult.error)
      }
    } catch (error) {
      toast({
        title: "결제 실패",
        description: "결제 처리 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    } finally {
      setIsProcessing(false)
    }
  }

  const handleTossPayment = async (orderId: number, paymentId: number) => {
    // 토스페이먼츠 SDK 로딩 체크
    if (typeof window === "undefined" || !(window as any).TossPayments) {
      toast({
        title: "오류",
        description: "결제 시스템을 불러오는 중입니다. 잠시 후 다시 시도해주세요.",
        variant: "destructive",
      })
      return
    }

    if (!tossClientKey) {
      toast({
        title: "오류",
        description: "결제 시스템을 불러오는 중입니다. 잠시 후 다시 시도해주세요.",
        variant: "destructive",
      })
      return
    }

    // TossPayments SDK instance
    const tossPayments = (window as any).TossPayments(tossClientKey)

    try {
      await tossPayments.requestPayment("카드", {
        amount: totalAmount,
        orderId: `order-${orderId}-${paymentId}`,
        orderName: `${product.name} ${quantity}개`,
        customerName: customerInfo.name,
        customerEmail: customerInfo.email,
        successUrl: `${window.location.origin}/payment/success`,
        failUrl: `${window.location.origin}/payment/fail`,
      })
    } catch (error) {
      console.error("Toss payment error:", error)
      toast({
        title: "결제 실패",
        description: "토스페이먼츠 결제 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleKakaoPayment = async (orderId: number, paymentId: number) => {
    try {
      const response = await fetch("/api/payments/kakaopay", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          order_id: orderId,
          payment_id: paymentId,
          amount: totalAmount,
          item_name: `${product.name} ${quantity}개`,
        }),
      })

      const result = await response.json()

      if (result.success) {
        window.location.href = result.redirect_url
      } else {
        throw new Error(result.error)
      }
    } catch (error) {
      toast({
        title: "결제 실패",
        description: "카카오페이 결제 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleBankTransfer = async (orderId: number) => {
    toast({
      title: "주문 완료",
      description: "무통장입금 정보를 확인해주세요. 입금 확인 후 배송이 시작됩니다.",
    })

    // 무통장입금 안내 페이지로 이동
    window.location.href = `/payment/bank-transfer?order_id=${orderId}`
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-2xl">주문 및 결제</CardTitle>
            <CardDescription>주문 정보를 확인하고 결제를 진행해주세요</CardDescription>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* 주문 상품 정보 */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-semibold mb-3">주문 상품</h3>
            <div className="flex justify-between items-center">
              <div>
                <span className="font-medium">{product.name}</span>
                <span className="text-gray-600 ml-2">× {quantity}</span>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-blue-600">₩{totalAmount.toLocaleString()}</div>
                <div className="text-sm text-gray-600">(개당 ₩{product.price.toLocaleString()})</div>
              </div>
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {/* 주문자 정보 */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">주문자 정보</h3>
              <div>
                <Label htmlFor="customer-name">이름 *</Label>
                <Input
                  id="customer-name"
                  value={customerInfo.name}
                  onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                  placeholder="홍길동"
                />
              </div>
              <div>
                <Label htmlFor="customer-phone">연락처 *</Label>
                <Input
                  id="customer-phone"
                  value={customerInfo.phone}
                  onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
                  placeholder="010-1234-5678"
                />
              </div>
              <div>
                <Label htmlFor="customer-email">이메일</Label>
                <Input
                  id="customer-email"
                  type="email"
                  value={customerInfo.email}
                  onChange={(e) => setCustomerInfo({ ...customerInfo, email: e.target.value })}
                  placeholder="example@email.com"
                />
              </div>
            </div>

            {/* 배송 정보 */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">배송 정보</h3>
              <div>
                <Label htmlFor="recipient-name">받는 분 *</Label>
                <Input
                  id="recipient-name"
                  value={shippingInfo.recipient_name}
                  onChange={(e) => setShippingInfo({ ...shippingInfo, recipient_name: e.target.value })}
                  placeholder="홍길동"
                />
              </div>
              <div>
                <Label htmlFor="recipient-phone">연락처 *</Label>
                <Input
                  id="recipient-phone"
                  value={shippingInfo.recipient_phone}
                  onChange={(e) => setShippingInfo({ ...shippingInfo, recipient_phone: e.target.value })}
                  placeholder="010-1234-5678"
                />
              </div>
              <div>
                <Label htmlFor="address">주소 *</Label>
                <Input
                  id="address"
                  value={shippingInfo.address}
                  onChange={(e) => setShippingInfo({ ...shippingInfo, address: e.target.value })}
                  placeholder="서울시 강남구 테헤란로 123"
                />
              </div>
              <div>
                <Label htmlFor="detailed-address">상세주소</Label>
                <Input
                  id="detailed-address"
                  value={shippingInfo.detailed_address}
                  onChange={(e) => setShippingInfo({ ...shippingInfo, detailed_address: e.target.value })}
                  placeholder="101동 1001호"
                />
              </div>
              <div>
                <Label htmlFor="delivery-request">배송 요청사항</Label>
                <Textarea
                  id="delivery-request"
                  value={shippingInfo.delivery_request}
                  onChange={(e) => setShippingInfo({ ...shippingInfo, delivery_request: e.target.value })}
                  placeholder="배송 시 요청사항을 입력해주세요"
                  rows={3}
                />
              </div>
            </div>
          </div>

          {/* 결제 방법 */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">결제 방법</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card
                className={`cursor-pointer transition-colors ${paymentMethod === "toss" ? "ring-2 ring-blue-500 bg-blue-50" : "hover:bg-gray-50"}`}
                onClick={() => setPaymentMethod("toss")}
              >
                <CardContent className="p-4 text-center">
                  <CreditCard className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                  <div className="font-medium">토스페이먼츠</div>
                  <div className="text-sm text-gray-600">카드/계좌이체</div>
                </CardContent>
              </Card>

              <Card
                className={`cursor-pointer transition-colors ${paymentMethod === "kakaopay" ? "ring-2 ring-yellow-500 bg-yellow-50" : "hover:bg-gray-50"}`}
                onClick={() => setPaymentMethod("kakaopay")}
              >
                <CardContent className="p-4 text-center">
                  <Smartphone className="h-8 w-8 mx-auto mb-2 text-yellow-600" />
                  <div className="font-medium">카카오페이</div>
                  <div className="text-sm text-gray-600">간편결제</div>
                </CardContent>
              </Card>

              <Card
                className={`cursor-pointer transition-colors ${paymentMethod === "bank_transfer" ? "ring-2 ring-green-500 bg-green-50" : "hover:bg-gray-50"}`}
                onClick={() => setPaymentMethod("bank_transfer")}
              >
                <CardContent className="p-4 text-center">
                  <Building className="h-8 w-8 mx-auto mb-2 text-green-600" />
                  <div className="font-medium">무통장입금</div>
                  <div className="text-sm text-gray-600">계좌이체</div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* 결제 금액 */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-between items-center text-lg font-bold">
              <span>총 결제금액</span>
              <span className="text-2xl text-blue-600">₩{totalAmount.toLocaleString()}</span>
            </div>
            <div className="text-sm text-gray-600 mt-2">무료배송 • 설치서비스 포함</div>
          </div>

          {/* 결제 버튼 */}
          <div className="flex gap-3 pt-4">
            <Button variant="outline" className="flex-1 bg-transparent" onClick={onClose} disabled={isProcessing}>
              취소
            </Button>
            <Button className="flex-1" onClick={handlePayment} disabled={isProcessing}>
              {isProcessing ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  처리중...
                </>
              ) : (
                `₩${totalAmount.toLocaleString()} 결제하기`
              )}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
