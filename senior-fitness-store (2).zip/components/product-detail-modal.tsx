"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { FileUpload } from "@/components/file-upload"
import { X, Save } from "lucide-react"

interface Product {
  id: number
  name: string
  description: string
  regular_price: number
  sale_price: number
  discount_rate: number
  features: string[]
  detail_page_url?: string
  image_url?: string
}

interface ProductDetailModalProps {
  isOpen: boolean
  onClose: () => void
  product: Product
  onSave: (product: Product) => void
}

export function ProductDetailModal({ isOpen, onClose, product, onSave }: ProductDetailModalProps) {
  const [editedProduct, setEditedProduct] = useState<Product>(product)
  const [productImages, setProductImages] = useState<string[]>([product.image_url || ""])

  if (!isOpen) return null

  const handleSave = () => {
    onSave({
      ...editedProduct,
      image_url: productImages[0],
    })
    onClose()
  }

  const addImage = (url: string) => {
    setProductImages([...productImages, url])
  }

  const removeImage = (index: number) => {
    setProductImages(productImages.filter((_, i) => i !== index))
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-2xl">상품 상세 관리</CardTitle>
            <CardDescription>{product.name}</CardDescription>
          </div>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="h-4 w-4" />
          </Button>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* 기본 정보 */}
            <div className="space-y-4">
              <div>
                <Label>상품명</Label>
                <Input
                  value={editedProduct.name}
                  onChange={(e) => setEditedProduct({ ...editedProduct, name: e.target.value })}
                />
              </div>
              <div>
                <Label>상품 설명</Label>
                <Textarea
                  value={editedProduct.description}
                  rows={4}
                  onChange={(e) => setEditedProduct({ ...editedProduct, description: e.target.value })}
                />
              </div>
              <div>
                <Label>상품 특징 (한 줄씩 입력)</Label>
                <Textarea
                  value={editedProduct.features?.join("\n") || ""}
                  rows={5}
                  onChange={(e) =>
                    setEditedProduct({ ...editedProduct, features: e.target.value.split("\n").filter(Boolean) })
                  }
                />
              </div>
            </div>

            {/* 가격 정보 */}
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label>정상가</Label>
                  <Input
                    type="number"
                    value={editedProduct.regular_price}
                    onChange={(e) =>
                      setEditedProduct({ ...editedProduct, regular_price: Number.parseInt(e.target.value) })
                    }
                  />
                </div>
                <div>
                  <Label>할인가</Label>
                  <Input
                    type="number"
                    value={editedProduct.sale_price}
                    onChange={(e) =>
                      setEditedProduct({ ...editedProduct, sale_price: Number.parseInt(e.target.value) })
                    }
                  />
                </div>
                <div>
                  <Label>할인율(%)</Label>
                  <Input
                    type="number"
                    value={editedProduct.discount_rate}
                    onChange={(e) =>
                      setEditedProduct({ ...editedProduct, discount_rate: Number.parseInt(e.target.value) })
                    }
                  />
                </div>
              </div>

              <div>
                <Label>상세 페이지 URL</Label>
                <Input
                  value={editedProduct.detail_page_url || ""}
                  placeholder="https://example.com/product-detail"
                  onChange={(e) => setEditedProduct({ ...editedProduct, detail_page_url: e.target.value })}
                />
              </div>

              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <span className="font-medium">할인 적용 가격</span>
                  <Badge variant="secondary">
                    {Math.round(
                      ((editedProduct.regular_price - editedProduct.sale_price) / editedProduct.regular_price) * 100,
                    )}
                    % 할인
                  </Badge>
                </div>
                <div className="text-2xl font-bold text-blue-600">₩{editedProduct.sale_price.toLocaleString()}</div>
                <div className="text-sm text-gray-500 line-through">
                  ₩{editedProduct.regular_price.toLocaleString()}
                </div>
              </div>
            </div>
          </div>

          {/* 이미지 관리 */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">상품 이미지 관리</h3>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <Label>새 이미지 업로드</Label>
                <FileUpload onUpload={addImage} accept="image/*" />
              </div>

              <div>
                <Label>현재 이미지들</Label>
                <div className="space-y-3 max-h-60 overflow-y-auto">
                  {productImages.filter(Boolean).map((image, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 border rounded-lg">
                      <div className="w-16 h-16 relative">
                        <Image
                          src={image || "/placeholder.svg"}
                          alt={`상품 이미지 ${index + 1}`}
                          fill
                          className="object-cover rounded"
                        />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">이미지 {index + 1}</p>
                        <p className="text-xs text-gray-600 truncate">{image}</p>
                      </div>
                      <Button size="sm" variant="destructive" onClick={() => removeImage(index)}>
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                  {productImages.filter(Boolean).length === 0 && (
                    <p className="text-gray-500 text-center py-8">등록된 이미지가 없습니다</p>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* 저장 버튼 */}
          <div className="flex gap-3 pt-4 border-t">
            <Button variant="outline" className="flex-1 bg-transparent" onClick={onClose}>
              취소
            </Button>
            <Button className="flex-1" onClick={handleSave}>
              <Save className="mr-2 h-4 w-4" />
              저장하기
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
