"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useToast } from "@/hooks/use-toast"
import { Upload, FileImage } from "lucide-react"

interface FileUploadProps {
  onUpload: (url: string) => void
  accept?: string
  maxSize?: number // MB
  currentFile?: string
}

export function FileUpload({ onUpload, accept = "image/*", maxSize = 5, currentFile }: FileUploadProps) {
  const [uploading, setUploading] = useState(false)
  const [dragOver, setDragOver] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const { toast } = useToast()

  const handleFileSelect = async (file: File) => {
    if (file.size > maxSize * 1024 * 1024) {
      toast({
        title: "파일 크기 초과",
        description: `파일 크기는 ${maxSize}MB 이하여야 합니다.`,
        variant: "destructive",
      })
      return
    }

    setUploading(true)
    try {
      // 실제 구현에서는 파일을 서버에 업로드하고 URL을 받아옵니다
      // 여기서는 임시로 File URL을 생성합니다
      const url = URL.createObjectURL(file)
      onUpload(url)

      toast({
        title: "업로드 완료",
        description: "파일이 성공적으로 업로드되었습니다.",
      })
    } catch (error) {
      toast({
        title: "업로드 실패",
        description: "파일 업로드 중 오류가 발생했습니다.",
        variant: "destructive",
      })
    } finally {
      setUploading(false)
    }
  }

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragOver(false)

    const files = Array.from(e.dataTransfer.files)
    if (files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files
    if (files && files.length > 0) {
      handleFileSelect(files[0])
    }
  }

  return (
    <div className="space-y-4">
      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
          dragOver ? "border-blue-500 bg-blue-50" : "border-gray-300"
        }`}
        onDrop={handleDrop}
        onDragOver={(e) => {
          e.preventDefault()
          setDragOver(true)
        }}
        onDragLeave={() => setDragOver(false)}
      >
        {currentFile ? (
          <div className="space-y-4">
            <div className="flex items-center justify-center">
              <FileImage className="h-12 w-12 text-green-600" />
            </div>
            <p className="text-sm text-gray-600">현재 파일: {currentFile}</p>
            <Button variant="outline" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
              파일 변경
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-center">
              <Upload className="h-12 w-12 text-gray-400" />
            </div>
            <div>
              <p className="text-lg font-medium">파일을 드래그하거나 클릭하여 업로드</p>
              <p className="text-sm text-gray-600">최대 {maxSize}MB</p>
            </div>
            <Button variant="outline" onClick={() => fileInputRef.current?.click()} disabled={uploading}>
              {uploading ? "업로드 중..." : "파일 선택"}
            </Button>
          </div>
        )}
      </div>

      <Input ref={fileInputRef} type="file" accept={accept} onChange={handleFileChange} className="hidden" />
    </div>
  )
}
