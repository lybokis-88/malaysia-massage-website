import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Phone, Handshake } from "lucide-react"

export default function HomePage() {
  const products = [
    {
      id: 1,
      name: "효도88 시즌1",
      price: "299,000원",
      description: "저강도 운동으로 안전하게 걷기 운동을 할 수 있는 워킹머신",
      image: "/placeholder.svg?height=300&width=400",
      features: ["안전 손잡이", "속도 조절", "심박수 측정"],
    },
    {
      id: 2,
      name: "효도88 시즌2",
      price: "189,000원",
      description: "앉아서 편안하게 전신 스트레칭이 가능한 전용 의자",
      image: "/placeholder.svg?height=300&width=400",
      features: ["등받이 조절", "팔걸이 스트레칭", "발목 운동"],
    },
    {
      id: 3,
      name: "케어88 상하지 운동기구",
      price: "149,000원",
      description: "균형감각 향상과 낙상 예방을 위한 안전한 운동기구",
      image: "/placeholder.svg?height=300&width=400",
      features: ["안전 바", "미끄럼 방지", "단계별 훈련"],
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20 text-emerald-700">
            <nav className="hidden md:flex space-x-8">
              <Link href="/about" className="text-lg hover:text-blue-600 font-medium text-emerald-700">
                회사소개
              </Link>
              <Link href="/products" className="text-lg text-gray-700 hover:text-blue-600 font-medium">
                제품소개
              </Link>
              <Link href="/consultation" className="text-lg text-gray-700 hover:text-blue-600 font-medium">
                상담하기
              </Link>
              <Link href="/b2b" className="text-lg text-gray-700 hover:text-blue-600 font-medium">
                B2B 제휴
              </Link>
              <Link href="/tiktok-live" className="text-lg text-gray-700 hover:text-blue-600 font-medium">
                틱톡 라이브
              </Link>
            </nav>
            <div className="flex items-center">
              <span className="font-bold text-rose-800 text-2xl">(주)이노브로텍</span>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-5xl font-bold text-gray-900 mb-6">
            건강한 노후를 위한
            <br />
            <span className="text-rose-800 text-4xl">전기 자동 헬스 기구</span>
          </h2>
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed font-bold">
            실버 헬스 케어 전문 기업 이노브로텍의 효도88, 케어88 시리즈로
            <br />
            건강하고 행복한 실버라이프를 즐기세요.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center"></div>
        </div>
      </section>

      {/* Happy Couple Section */}
      <section className="py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <Image
                src="/images/happy-korean-elderly-couple.png"
                alt="활기차게 운동하고 행복해하시는 한국인 노부부"
                width={600}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
            <div>
              <h3 className="text-3xl font-bold text-gray-900 mb-6">건강하고 행복한 실버라이프</h3>
              <p className="text-gray-600 mb-6 leading-relaxed font-bold text-xl">
                이노브로텍의 효도88, 케어88 시리즈와 함께 매일 즐겁게 운동하며 건강한 노후를 보내고 계신 고객님들의
                모습입니다.
              </p>
              <p className="text-gray-600 mb-8 leading-relaxed font-bold text-xl">
                안전하고 효과적인 운동기구로 부부가 함께 건강을 지키며 활기찬 일상을 만들어가세요.
              </p>
              <Button size="lg" className="text-lg px-8 py-4 h-auto text-emerald-300 bg-rose-800">
                <Phone className="mr-2 h-5 w-5" />
                무료 체험 신청하기
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}

      {/* Products */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <h3 className="text-3xl font-bold text-center mb-12 text-rose-800">{"효도88 케어88 시리즈"}</h3>
          <div className="grid md:grid-cols-3 gap-8">
            {products.map((product) => (
              <Card key={product.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-[4/3] relative">
                  <Image src={product.image || "/placeholder.svg"} alt={product.name} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{product.name}</CardTitle>
                  <CardDescription className="text-lg">{product.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <ul className="text-sm text-gray-600 space-y-1">
                      {product.features.map((feature, index) => (
                        <li key={index}>• {feature}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-blue-600">{product.price}</span>
                    <Link href={`/product/${product.id}`}>
                      <Button size="lg" className="text-lg px-6">
                        구매하기
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 text-white bg-rose-800">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h3 className="text-3xl font-bold mb-6">건강한 노후, 지금 시작하세요</h3>
          <p className="text-xl mb-8 leading-relaxed">
            전문 상담사가 어르신의 건강 상태에 맞는 최적의 운동기구를 추천해드립니다
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/consultation">
              <Button size="lg" variant="secondary" className="text-lg px-8 py-4 h-auto">
                <Phone className="mr-2 h-5 w-5" />
                무료 상담 신청
              </Button>
            </Link>
            <Link href="/b2b">
              <Button
                size="lg"
                variant="outline"
                className="text-lg px-8 py-4 h-auto border-white text-white hover:bg-white hover:text-blue-600 bg-transparent"
              >
                <Handshake className="mr-2 h-5 w-5" />
                B2B 제휴 문의
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="text-white py-12 bg-gray-700">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h4 className="text-xl font-bold mb-4">(주)이노브로텍</h4>
              <p className="text-gray-400 leading-relaxed">
                건강한 노후를 위한
                <br />
                맞춤형 운동기구 전문업체
              </p>
            </div>
            <div>
              <h5 className="font-semibold mb-4 text-lg">제품</h5>
              <ul className="space-y-2 text-gray-400">
                <li>실버 워킹머신</li>
                <li>시니어 스트레칭 체어</li>
                <li>균형감각 트레이너</li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4 text-lg">서비스</h5>
              <ul className="space-y-2 text-gray-400">
                <li>무료 상담</li>
                <li>설치 서비스</li>
                <li>A/S 지원</li>
              </ul>
            </div>
            <div>
              <h5 className="font-semibold mb-4 text-lg">연락처</h5>
              <ul className="space-y-2 text-gray-400">
                <li>전화: 1588-0000</li>
                <li>이메일: info@innovrotech.co.kr</li>
                <li>주소: 서울시 강남구</li>
                <li>홈페이지: www.innovrotech.co.kr</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2025 (주)이노브로텍. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  )
}
