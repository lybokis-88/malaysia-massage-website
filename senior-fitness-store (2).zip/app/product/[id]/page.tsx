"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Shield, Award, Truck, Phone, Minus, Plus } from "lucide-react"
import { PaymentModal } from "@/components/payment-modal"
import { ClientWrapper } from "@/components/client-wrapper"

export default function ProductDetailPage({ params }: { params: { id: string } }) {
  const [quantity, setQuantity] = useState(1)
  const [showPaymentModal, setShowPaymentModal] = useState(false)

  // Mock product data - in real app, fetch based on params.id
  const product = {
    id: 1,
    name: "효도88 시즌1",
    price: 299000,
    originalPrice: 349000,
    description:
      "저강도 운동으로 안전하게 걷기 운동을 할 수 있는 워킹머신입니다. 관절에 무리가 가지 않는 설계로 매일 꾸준한 유산소 운동이 가능합니다.",
    images: [
      "/placeholder.svg?height=500&width=600",
      "/placeholder.svg?height=500&width=600",
      "/placeholder.svg?height=500&width=600",
    ],
    features: ["안전 손잡이", "속도 조절 (0.5-6km/h)", "심박수 측정", "LCD 디스플레이", "접이식 설계"],
    benefits: ["심폐기능 향상", "하체 근력 강화", "균형감각 개선"],
    specifications: {
      크기: "150cm × 70cm × 130cm",
      무게: "45kg",
      "최대 사용자 무게": "120kg",
      "속도 범위": "0.5 - 6.0 km/h",
      전원: "220V",
      보증기간: "2년",
    },
    rating: 4.8,
    reviews: 156,
    badge: "베스트셀러",
  }

  const handleQuantityChange = (change: number) => {
    setQuantity(Math.max(1, quantity + change))
  }

  const totalPrice = product.price * quantity

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link href="/" className="flex items-center">
              <Image src="/images/logo.jpg" alt="이노브로텍 로고" width={40} height={40} className="mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">(주)이노브로텍</h1>
            </Link>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Product Images */}
          <div>
            <div className="relative mb-4">
              <Image
                src={product.images[0] || "/placeholder.svg"}
                alt={product.name}
                width={600}
                height={500}
                className="w-full rounded-lg shadow-lg"
              />
              {product.badge && (
                <Badge className="absolute top-4 left-4 bg-red-500 text-white text-sm px-3 py-1">{product.badge}</Badge>
              )}
            </div>
            <div className="grid grid-cols-3 gap-4">
              {product.images.map((image, index) => (
                <Image
                  key={index}
                  src={image || "/placeholder.svg"}
                  alt={`${product.name} ${index + 1}`}
                  width={200}
                  height={150}
                  className="w-full rounded-lg border-2 border-gray-200 hover:border-blue-500 cursor-pointer"
                />
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-5 w-5 ${
                      i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm text-gray-600">
                {product.rating} ({product.reviews}개 리뷰)
              </span>
            </div>

            <h1 className="text-4xl font-bold text-gray-900 mb-4">{product.name}</h1>

            <div className="flex items-center gap-4 mb-6">
              <span className="text-4xl font-bold text-blue-600">{product.price.toLocaleString()}원</span>
              <span className="text-xl text-gray-500 line-through">{product.originalPrice.toLocaleString()}원</span>
              <Badge variant="destructive" className="text-sm">
                {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% 할인
              </Badge>
            </div>

            <p className="text-lg text-gray-600 mb-8 leading-relaxed">{product.description}</p>

            {/* Features */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <Shield className="h-5 w-5 mr-2 text-blue-600" />
                주요 기능
              </h3>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {product.features.map((feature, idx) => (
                  <li key={idx} className="text-gray-600 flex items-center">
                    <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {/* Benefits */}
            <div className="mb-8">
              <h3 className="text-lg font-semibold mb-4 flex items-center">
                <Award className="h-5 w-5 mr-2 text-green-600" />
                운동 효과
              </h3>
              <div className="flex flex-wrap gap-2">
                {product.benefits.map((benefit, idx) => (
                  <Badge key={idx} variant="secondary" className="text-sm">
                    {benefit}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Quantity and Purchase */}
            <div className="border-t pt-8">
              <div className="flex items-center gap-4 mb-6">
                <label htmlFor="quantity" className="text-lg font-medium">
                  수량:
                </label>
                <div className="flex items-center border rounded-lg">
                  <Button variant="ghost" size="sm" onClick={() => handleQuantityChange(-1)} disabled={quantity <= 1}>
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="px-4 py-2 text-lg font-medium">{quantity}</span>
                  <Button variant="ghost" size="sm" onClick={() => handleQuantityChange(1)}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg mb-6">
                <div className="flex justify-between items-center text-lg">
                  <span>총 결제금액:</span>
                  <span className="text-2xl font-bold text-blue-600">{totalPrice.toLocaleString()}원</span>
                </div>
                <p className="text-sm text-green-600 mt-2">
                  <Truck className="inline h-4 w-4 mr-1" />
                  무료배송 • 설치서비스 포함
                </p>
              </div>

              <div className="flex flex-col gap-3">
                <Button size="lg" className="w-full text-lg py-4 h-auto" onClick={() => setShowPaymentModal(true)}>
                  바로 구매하기
                </Button>
                <Button size="lg" variant="outline" className="w-full text-lg py-4 h-auto bg-transparent">
                  <Phone className="mr-2 h-5 w-5" />
                  전화 주문 (1588-0000)
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Product Specifications */}
        <div className="mt-16">
          <h2 className="text-2xl font-bold mb-8">제품 사양</h2>
          <Card>
            <CardContent className="p-6">
              <div className="grid md:grid-cols-2 gap-6">
                {Object.entries(product.specifications).map(([key, value]) => (
                  <div key={key} className="flex justify-between py-2 border-b border-gray-100">
                    <span className="font-medium text-gray-700">{key}</span>
                    <span className="text-gray-600">{value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Payment Modal */}
      <ClientWrapper>
        <PaymentModal
          isOpen={showPaymentModal}
          onClose={() => setShowPaymentModal(false)}
          product={{
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.images[0],
          }}
          quantity={quantity}
        />
      </ClientWrapper>
    </div>
  )
}
