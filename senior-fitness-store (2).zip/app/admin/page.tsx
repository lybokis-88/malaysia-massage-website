"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { ClientWrapper } from "@/components/client-wrapper"
import { FileUpload } from "@/components/file-upload"
import { ProductDetailModal } from "@/components/product-detail-modal"
import {
  Save,
  Edit,
  Trash2,
  Eye,
  ShoppingCart,
  Users,
  Package,
  ImageIcon,
  DollarSign,
  Building,
  MessageSquare,
  Phone,
  Mail,
  CheckCircle,
  Clock,
  AlertCircle,
  Handshake,
} from "lucide-react"

// 인터페이스 정의들
interface UploadedImage {
  id: number
  section: string
  title: string
  url: string
  type: "file" | "url"
}

interface Product {
  id: number
  name: string
  description: string
  regular_price: number
  sale_price: number
  discount_rate: number
  features: string[]
  detail_page_url?: string
  image_url?: string
}

interface Customer {
  id: number
  name: string
  phone1: string
  phone2?: string
  address: string
  memo?: string
  order_count: number
  total_spent: number
}

interface Order {
  id: number
  customer_name: string
  customer_phone: string
  product_name: string
  total_amount: number
  status: string
  order_date: string
  payment_method: string
  payment_status: string
}

interface OrderStats {
  total_orders: number
  total_revenue: number
  pending_orders: number
  processing_orders: number
  shipped_orders: number
  delivered_orders: number
}

interface FooterInfo {
  company_name: string
  phone: string
  email: string
  address: string
  website: string
}

interface CompanyInfo {
  id: number
  section: string
  title: string
  content: string
  image_url?: string
  display_order: number
}

interface ConsultationRequest {
  id: number
  name: string
  age?: number
  phone: string
  email?: string
  health_condition?: string
  medical_history?: string[]
  exercise_experience?: string
  exercise_goal?: string
  additional_info?: string
  contact_time?: string
  status: string
  admin_notes?: string
  contacted_at?: string
  created_at: string
}

interface B2BRequest {
  id: number
  company_name: string
  business_type?: string
  company_size?: string
  annual_revenue?: string
  contact_name: string
  contact_position?: string
  contact_phone: string
  contact_email: string
  partnership_type?: string
  target_products?: string[]
  expected_volume?: string
  additional_info?: string
  status: string
  admin_response?: string
  admin_notes?: string
  responded_at?: string
  created_at: string
}

export default function AdminPage() {
  const [activeTab, setActiveTab] = useState("images")
  const [isLoading, setIsLoading] = useState(true)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [showProductModal, setShowProductModal] = useState(false)
  const { toast } = useToast()

  // 상태 관리
  const [images, setImages] = useState<UploadedImage[]>([])
  const [products, setProducts] = useState<Product[]>([])
  const [customers, setCustomers] = useState<Customer[]>([])
  const [orders, setOrders] = useState<Order[]>([])
  const [orderStats, setOrderStats] = useState<OrderStats | null>(null)
  const [footerInfo, setFooterInfo] = useState<FooterInfo>({
    company_name: "",
    phone: "",
    email: "",
    address: "",
    website: "",
  })
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo[]>([])
  const [consultationRequests, setConsultationRequests] = useState<ConsultationRequest[]>([])
  const [b2bRequests, setB2BRequests] = useState<B2BRequest[]>([])

  // 새 이미지 폼 상태
  const [newImage, setNewImage] = useState({
    section: "",
    title: "",
    url: "",
    type: "file" as "file" | "url",
  })

  // 새 회사 정보 폼 상태
  const [newCompanyInfo, setNewCompanyInfo] = useState({
    section: "",
    title: "",
    content: "",
    image_url: "",
    display_order: 0,
  })

  // 데이터 로딩
  useEffect(() => {
    const loadAllData = async () => {
      setIsLoading(true)
      try {
        await Promise.all([
          loadImages(),
          loadProducts(),
          loadCustomers(),
          loadOrders(),
          loadOrderStats(),
          loadFooterInfo(),
          loadCompanyInfo(),
          loadConsultationRequests(),
          loadB2BRequests(),
        ])
      } catch (error) {
        console.error("데이터 로딩 오류:", error)
        toast({
          title: "오류",
          description: "데이터를 불러오는 중 오류가 발생했습니다.",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    loadAllData()
  }, [])

  // 기존 로딩 함수들
  const loadImages = async () => {
    try {
      const response = await fetch("/api/images")
      if (response.ok) {
        const data = await response.json()
        setImages(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error("이미지 로딩 오류:", error)
    }
  }

  const loadProducts = async () => {
    try {
      const response = await fetch("/api/products")
      if (response.ok) {
        const data = await response.json()
        setProducts(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error("상품 로딩 오류:", error)
    }
  }

  const loadCustomers = async () => {
    try {
      const response = await fetch("/api/customers")
      if (response.ok) {
        const data = await response.json()
        setCustomers(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error("고객 로딩 오류:", error)
    }
  }

  const loadOrders = async () => {
    try {
      const response = await fetch("/api/orders")
      if (response.ok) {
        const data = await response.json()
        setOrders(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error("주문 로딩 오류:", error)
    }
  }

  const loadOrderStats = async () => {
    try {
      const response = await fetch("/api/orders?stats=true")
      if (response.ok) {
        const data = await response.json()
        setOrderStats(data)
      }
    } catch (error) {
      console.error("주문 통계 로딩 오류:", error)
    }
  }

  const loadFooterInfo = async () => {
    try {
      const response = await fetch("/api/footer")
      if (response.ok) {
        const data = await response.json()
        if (data) {
          setFooterInfo(data)
        }
      }
    } catch (error) {
      console.error("푸터 정보 로딩 오류:", error)
    }
  }

  // 새로운 로딩 함수들
  const loadCompanyInfo = async () => {
    try {
      const response = await fetch("/api/company-info")
      if (response.ok) {
        const data = await response.json()
        setCompanyInfo(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error("회사 정보 로딩 오류:", error)
    }
  }

  const loadConsultationRequests = async () => {
    try {
      const response = await fetch("/api/consultation-requests")
      if (response.ok) {
        const data = await response.json()
        setConsultationRequests(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error("상담 신청 로딩 오류:", error)
    }
  }

  const loadB2BRequests = async () => {
    try {
      const response = await fetch("/api/b2b-requests")
      if (response.ok) {
        const data = await response.json()
        setB2BRequests(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error("B2B 제휴 문의 로딩 오류:", error)
    }
  }

  // 기존 핸들러 함수들
  const handleCreateImage = async () => {
    if (!newImage.section || !newImage.title || !newImage.url) {
      toast({
        title: "오류",
        description: "모든 필드를 입력해주세요.",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch("/api/images", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newImage),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "이미지가 추가되었습니다.",
        })
        setNewImage({ section: "", title: "", url: "", type: "file" })
        loadImages()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "이미지 추가에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteImage = async (id: number) => {
    try {
      const response = await fetch(`/api/images/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "이미지가 삭제되었습니다.",
        })
        loadImages()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "이미지 삭제에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateProduct = async (id: number, data: Partial<Product>) => {
    try {
      const response = await fetch(`/api/products/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "상품이 업데이트되었습니다.",
        })
        loadProducts()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "상품 업데이트에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateCustomer = async (id: number, data: Partial<Customer>) => {
    try {
      const response = await fetch(`/api/customers/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "고객 정보가 업데이트되었습니다.",
        })
        loadCustomers()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "고객 정보 업데이트에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateOrderStatus = async (id: number, status: string) => {
    try {
      const response = await fetch(`/api/orders/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "주문 상태가 업데이트되었습니다.",
        })
        loadOrders()
        loadOrderStats()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "주문 상태 업데이트에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateFooter = async () => {
    try {
      const response = await fetch("/api/footer", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(footerInfo),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "푸터 정보가 업데이트되었습니다.",
        })
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "푸터 정보 업데이트에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  // 새로운 핸들러 함수들
  const handleCreateCompanyInfo = async () => {
    if (!newCompanyInfo.section || !newCompanyInfo.title || !newCompanyInfo.content) {
      toast({
        title: "오류",
        description: "필수 필드를 모두 입력해주세요.",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch("/api/company-info", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newCompanyInfo),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "회사 정보가 추가되었습니다.",
        })
        setNewCompanyInfo({ section: "", title: "", content: "", image_url: "", display_order: 0 })
        loadCompanyInfo()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "회사 정보 추가에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateCompanyInfo = async (id: number, data: Partial<CompanyInfo>) => {
    try {
      const response = await fetch(`/api/company-info/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "회사 정보가 업데이트되었습니다.",
        })
        loadCompanyInfo()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "회사 정보 업데이트에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleDeleteCompanyInfo = async (id: number) => {
    try {
      const response = await fetch(`/api/company-info/${id}`, {
        method: "DELETE",
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "회사 정보가 삭제되었습니다.",
        })
        loadCompanyInfo()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "회사 정보 삭제에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateConsultationRequest = async (id: number, data: Partial<ConsultationRequest>) => {
    try {
      const response = await fetch(`/api/consultation-requests/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "상담 신청 정보가 업데이트되었습니다.",
        })
        loadConsultationRequests()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "상담 신청 정보 업데이트에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const handleUpdateB2BRequest = async (id: number, data: Partial<B2BRequest>) => {
    try {
      const response = await fetch(`/api/b2b-requests/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      })

      if (response.ok) {
        toast({
          title: "성공",
          description: "B2B 제휴 문의가 업데이트되었습니다.",
        })
        loadB2BRequests()
      }
    } catch (error) {
      toast({
        title: "오류",
        description: "B2B 제휴 문의 업데이트에 실패했습니다.",
        variant: "destructive",
      })
    }
  }

  const getStatusBadge = (status: string) => {
    const statusConfig = {
      pending: { label: "대기중", variant: "secondary" as const, icon: Clock },
      contacted: { label: "연락완료", variant: "default" as const, icon: Phone },
      completed: { label: "완료", variant: "default" as const, icon: CheckCircle },
      cancelled: { label: "취소", variant: "destructive" as const, icon: AlertCircle },
      reviewing: { label: "검토중", variant: "secondary" as const, icon: Clock },
      approved: { label: "승인", variant: "default" as const, icon: CheckCircle },
      rejected: { label: "거절", variant: "destructive" as const, icon: AlertCircle },
    }

    const config = statusConfig[status as keyof typeof statusConfig] || statusConfig.pending
    const Icon = config.icon

    return (
      <Badge variant={config.variant} className="flex items-center gap-1">
        <Icon className="h-3 w-3" />
        {config.label}
      </Badge>
    )
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">데이터를 불러오는 중...</p>
        </div>
      </div>
    )
  }

  return (
    <ClientWrapper>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <header className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center h-16">
              <h1 className="text-2xl font-bold text-gray-900">관리자 페이지</h1>
              <Badge variant="secondary">Admin</Badge>
            </div>
          </div>
        </header>

        <div className="max-w-7xl mx-auto px-4 py-8">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-7">
              <TabsTrigger value="images" className="flex items-center gap-2">
                <ImageIcon className="h-4 w-4" />
                이미지 관리
              </TabsTrigger>
              <TabsTrigger value="company" className="flex items-center gap-2">
                <Building className="h-4 w-4" />
                회사 소개
              </TabsTrigger>
              <TabsTrigger value="products" className="flex items-center gap-2">
                <Package className="h-4 w-4" />
                상품 관리
              </TabsTrigger>
              <TabsTrigger value="orders" className="flex items-center gap-2">
                <ShoppingCart className="h-4 w-4" />
                주문 관리
              </TabsTrigger>
              <TabsTrigger value="customers" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                고객 관리
              </TabsTrigger>
              <TabsTrigger value="consultation" className="flex items-center gap-2">
                <MessageSquare className="h-4 w-4" />
                상담 신청
              </TabsTrigger>
              <TabsTrigger value="b2b" className="flex items-center gap-2">
                <Handshake className="h-4 w-4" />
                B2B 제휴
              </TabsTrigger>
            </TabsList>

            {/* 이미지 관리 */}
            <TabsContent value="images" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>이미지 관리</CardTitle>
                  <CardDescription>각 섹션별 이미지를 업로드하고 관리합니다</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {/* 새 이미지 추가 */}
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                      <h3 className="text-lg font-semibold mb-4">새 이미지 추가</h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="section">섹션 선택</Label>
                            <Select
                              value={newImage.section}
                              onValueChange={(value) => setNewImage({ ...newImage, section: value })}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="섹션을 선택하세요" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="hero">히어로 섹션</SelectItem>
                                <SelectItem value="couple">노부부 섹션</SelectItem>
                                <SelectItem value="product1">상품 1</SelectItem>
                                <SelectItem value="product2">상품 2</SelectItem>
                                <SelectItem value="product3">상품 3</SelectItem>
                                <SelectItem value="company">회사 소개</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label htmlFor="title">이미지 타이틀</Label>
                            <Input
                              placeholder="이미지 제목을 입력하세요"
                              value={newImage.title}
                              onChange={(e) => setNewImage({ ...newImage, title: e.target.value })}
                            />
                          </div>
                        </div>
                        <div>
                          <Label>파일 업로드</Label>
                          <FileUpload
                            onUpload={(url) => setNewImage({ ...newImage, url, type: "file" })}
                            currentFile={newImage.url}
                          />
                        </div>
                      </div>
                      <div className="mt-4 space-y-4">
                        <div className="text-center text-gray-500">또는</div>
                        <div>
                          <Label>이미지 URL</Label>
                          <div className="flex items-center gap-4">
                            <Input
                              placeholder="https://example.com/image.jpg"
                              value={newImage.url}
                              onChange={(e) => setNewImage({ ...newImage, url: e.target.value, type: "url" })}
                            />
                            <Button variant="outline" onClick={handleCreateImage}>
                              추가
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* 기존 이미지 목록 */}
                    <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {images.map((image) => (
                        <Card key={image.id}>
                          <CardContent className="p-4">
                            <div className="aspect-video relative mb-4">
                              <Image
                                src={image.url || "/placeholder.svg"}
                                alt={image.title}
                                fill
                                className="object-cover rounded"
                              />
                            </div>
                            <div className="space-y-2">
                              <Badge variant={image.type === "file" ? "default" : "secondary"}>
                                {image.type === "file" ? "파일" : "URL"}
                              </Badge>
                              <h4 className="font-semibold">{image.title}</h4>
                              <p className="text-sm text-gray-600">섹션: {image.section}</p>
                              <div className="flex gap-2">
                                <Button size="sm" variant="outline">
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="outline">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="destructive" onClick={() => handleDeleteImage(image.id)}>
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* 회사 소개 관리 */}
            <TabsContent value="company" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>회사 소개 관리</CardTitle>
                  <CardDescription>회사 소개 페이지의 각 섹션을 관리합니다</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {/* 새 회사 정보 추가 */}
                    <div className="border-2 border-dashed border-gray-300 rounded-lg p-6">
                      <h3 className="text-lg font-semibold mb-4">새 섹션 추가</h3>
                      <div className="grid md:grid-cols-2 gap-6">
                        <div className="space-y-4">
                          <div>
                            <Label>섹션 타입</Label>
                            <Select
                              value={newCompanyInfo.section}
                              onValueChange={(value) => setNewCompanyInfo({ ...newCompanyInfo, section: value })}
                            >
                              <SelectTrigger>
                                <SelectValue placeholder="섹션을 선택하세요" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="about">회사 개요</SelectItem>
                                <SelectItem value="mission">미션</SelectItem>
                                <SelectItem value="vision">비전</SelectItem>
                                <SelectItem value="values">핵심 가치</SelectItem>
                                <SelectItem value="history">연혁</SelectItem>
                                <SelectItem value="team">팀 소개</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <Label>제목</Label>
                            <Input
                              placeholder="섹션 제목을 입력하세요"
                              value={newCompanyInfo.title}
                              onChange={(e) => setNewCompanyInfo({ ...newCompanyInfo, title: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label>내용</Label>
                            <Textarea
                              placeholder="섹션 내용을 입력하세요"
                              rows={4}
                              value={newCompanyInfo.content}
                              onChange={(e) => setNewCompanyInfo({ ...newCompanyInfo, content: e.target.value })}
                            />
                          </div>
                          <div>
                            <Label>표시 순서</Label>
                            <Input
                              type="number"
                              placeholder="0"
                              value={newCompanyInfo.display_order}
                              onChange={(e) =>
                                setNewCompanyInfo({ ...newCompanyInfo, display_order: Number.parseInt(e.target.value) })
                              }
                            />
                          </div>
                        </div>
                        <div>
                          <Label>섹션 이미지 (선택사항)</Label>
                          <FileUpload
                            onUpload={(url) => setNewCompanyInfo({ ...newCompanyInfo, image_url: url })}
                            currentFile={newCompanyInfo.image_url}
                          />
                        </div>
                      </div>
                      <div className="mt-4">
                        <Button onClick={handleCreateCompanyInfo}>
                          <Save className="mr-2 h-4 w-4" />
                          섹션 추가
                        </Button>
                      </div>
                    </div>

                    {/* 기존 회사 정보 목록 */}
                    <div className="space-y-4">
                      {companyInfo.map((info) => (
                        <Card key={info.id}>
                          <CardContent className="p-6">
                            <div className="grid md:grid-cols-2 gap-6">
                              <div className="space-y-4">
                                <div>
                                  <Label>섹션 타입</Label>
                                  <Input
                                    value={info.section}
                                    onChange={(e) => {
                                      const updatedInfo = companyInfo.map((item) =>
                                        item.id === info.id ? { ...item, section: e.target.value } : item,
                                      )
                                      setCompanyInfo(updatedInfo)
                                    }}
                                  />
                                </div>
                                <div>
                                  <Label>제목</Label>
                                  <Input
                                    value={info.title}
                                    onChange={(e) => {
                                      const updatedInfo = companyInfo.map((item) =>
                                        item.id === info.id ? { ...item, title: e.target.value } : item,
                                      )
                                      setCompanyInfo(updatedInfo)
                                    }}
                                  />
                                </div>
                                <div>
                                  <Label>내용</Label>
                                  <Textarea
                                    rows={4}
                                    value={info.content}
                                    onChange={(e) => {
                                      const updatedInfo = companyInfo.map((item) =>
                                        item.id === info.id ? { ...item, content: e.target.value } : item,
                                      )
                                      setCompanyInfo(updatedInfo)
                                    }}
                                  />
                                </div>
                                <div>
                                  <Label>표시 순서</Label>
                                  <Input
                                    type="number"
                                    value={info.display_order}
                                    onChange={(e) => {
                                      const updatedInfo = companyInfo.map((item) =>
                                        item.id === info.id
                                          ? { ...item, display_order: Number.parseInt(e.target.value) }
                                          : item,
                                      )
                                      setCompanyInfo(updatedInfo)
                                    }}
                                  />
                                </div>
                              </div>
                              <div className="space-y-4">
                                <div>
                                  <Label>섹션 이미지</Label>
                                  <FileUpload
                                    onUpload={(url) => {
                                      const updatedInfo = companyInfo.map((item) =>
                                        item.id === info.id ? { ...item, image_url: url } : item,
                                      )
                                      setCompanyInfo(updatedInfo)
                                    }}
                                    currentFile={info.image_url}
                                  />
                                </div>
                                <div className="flex gap-2">
                                  <Button onClick={() => handleUpdateCompanyInfo(info.id, info)}>
                                    <Save className="mr-2 h-4 w-4" />
                                    저장
                                  </Button>
                                  <Button variant="destructive" onClick={() => handleDeleteCompanyInfo(info.id)}>
                                    <Trash2 className="mr-2 h-4 w-4" />
                                    삭제
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* 상품 관리 */}
            <TabsContent value="products" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>상품 관리</CardTitle>
                  <CardDescription>상품 정보, 가격, 상세 페이지를 관리합니다</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {products.map((product) => (
                      <Card key={product.id}>
                        <CardContent className="p-6">
                          <div className="grid md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                              <div>
                                <Label>상품명</Label>
                                <Input
                                  value={product.name}
                                  onChange={(e) => {
                                    const updatedProducts = products.map((p) =>
                                      p.id === product.id ? { ...p, name: e.target.value } : p,
                                    )
                                    setProducts(updatedProducts)
                                  }}
                                />
                              </div>
                              <div>
                                <Label>상품 설명</Label>
                                <Textarea
                                  value={product.description}
                                  rows={3}
                                  onChange={(e) => {
                                    const updatedProducts = products.map((p) =>
                                      p.id === product.id ? { ...p, description: e.target.value } : p,
                                    )
                                    setProducts(updatedProducts)
                                  }}
                                />
                              </div>
                              <div>
                                <Label>상품 특징</Label>
                                <Textarea
                                  value={product.features?.join("\n") || ""}
                                  rows={3}
                                  onChange={(e) => {
                                    const updatedProducts = products.map((p) =>
                                      p.id === product.id ? { ...p, features: e.target.value.split("\n") } : p,
                                    )
                                    setProducts(updatedProducts)
                                  }}
                                />
                              </div>
                            </div>
                            <div className="space-y-4">
                              <div className="grid grid-cols-3 gap-4">
                                <div>
                                  <Label>정상가</Label>
                                  <Input
                                    type="number"
                                    value={product.regular_price}
                                    onChange={(e) => {
                                      const updatedProducts = products.map((p) =>
                                        p.id === product.id
                                          ? { ...p, regular_price: Number.parseInt(e.target.value) }
                                          : p,
                                      )
                                      setProducts(updatedProducts)
                                    }}
                                  />
                                </div>
                                <div>
                                  <Label>할인가</Label>
                                  <Input
                                    type="number"
                                    value={product.sale_price}
                                    onChange={(e) => {
                                      const updatedProducts = products.map((p) =>
                                        p.id === product.id ? { ...p, sale_price: Number.parseInt(e.target.value) } : p,
                                      )
                                      setProducts(updatedProducts)
                                    }}
                                  />
                                </div>
                                <div>
                                  <Label>할인율(%)</Label>
                                  <Input
                                    type="number"
                                    value={product.discount_rate}
                                    onChange={(e) => {
                                      const updatedProducts = products.map((p) =>
                                        p.id === product.id
                                          ? { ...p, discount_rate: Number.parseInt(e.target.value) }
                                          : p,
                                      )
                                      setProducts(updatedProducts)
                                    }}
                                  />
                                </div>
                              </div>
                              <div>
                                <Label>상품 이미지 업로드</Label>
                                <FileUpload
                                  onUpload={(url) => {
                                    const updatedProducts = products.map((p) =>
                                      p.id === product.id ? { ...p, image_url: url } : p,
                                    )
                                    setProducts(updatedProducts)
                                  }}
                                  currentFile={product.image_url}
                                />
                              </div>
                              <div className="flex gap-2">
                                <Button onClick={() => handleUpdateProduct(product.id, product)}>
                                  <Save className="h-4 w-4 mr-2" />
                                  저장
                                </Button>
                                <Button
                                  variant="outline"
                                  onClick={() => {
                                    setSelectedProduct(product)
                                    setShowProductModal(true)
                                  }}
                                >
                                  <Eye className="h-4 w-4 mr-2" />
                                  상세보기
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* 주문 관리 */}
            <TabsContent value="orders" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>주문 관리</CardTitle>
                  <CardDescription>결제 및 구매 현황을 관리합니다</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {orderStats && (
                      <div className="grid md:grid-cols-4 gap-4">
                        <Card>
                          <CardContent className="p-4 text-center">
                            <DollarSign className="h-8 w-8 mx-auto mb-2 text-green-600" />
                            <p className="text-2xl font-bold">₩{orderStats.total_revenue?.toLocaleString()}</p>
                            <p className="text-sm text-gray-600">총 매출</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4 text-center">
                            <ShoppingCart className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                            <p className="text-2xl font-bold">{orderStats.total_orders}</p>
                            <p className="text-sm text-gray-600">총 주문</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4 text-center">
                            <Package className="h-8 w-8 mx-auto mb-2 text-orange-600" />
                            <p className="text-2xl font-bold">{orderStats.shipped_orders}</p>
                            <p className="text-sm text-gray-600">배송 중</p>
                          </CardContent>
                        </Card>
                        <Card>
                          <CardContent className="p-4 text-center">
                            <Users className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                            <p className="text-2xl font-bold">{orderStats.delivered_orders}</p>
                            <p className="text-sm text-gray-600">완료</p>
                          </CardContent>
                        </Card>
                      </div>
                    )}

                    <div className="border rounded-lg overflow-hidden">
                      <table className="w-full">
                        <thead className="bg-gray-50">
                          <tr>
                            <th className="px-4 py-3 text-left">주문번호</th>
                            <th className="px-4 py-3 text-left">고객명</th>
                            <th className="px-4 py-3 text-left">상품</th>
                            <th className="px-4 py-3 text-left">금액</th>
                            <th className="px-4 py-3 text-left">상태</th>
                            <th className="px-4 py-3 text-left">관리</th>
                          </tr>
                        </thead>
                        <tbody>
                          {orders.map((order) => (
                            <tr key={order.id} className="border-t">
                              <td className="px-4 py-3">#{order.id.toString().padStart(4, "0")}</td>
                              <td className="px-4 py-3">{order.customer_name}</td>
                              <td className="px-4 py-3">{order.product_name}</td>
                              <td className="px-4 py-3">₩{order.total_amount.toLocaleString()}</td>
                              <td className="px-4 py-3">
                                <Select
                                  value={order.status}
                                  onValueChange={(value) => handleUpdateOrderStatus(order.id, value)}
                                >
                                  <SelectTrigger className="w-32">
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pending">대기</SelectItem>
                                    <SelectItem value="processing">처리중</SelectItem>
                                    <SelectItem value="shipped">배송중</SelectItem>
                                    <SelectItem value="delivered">완료</SelectItem>
                                    <SelectItem value="cancelled">취소</SelectItem>
                                  </SelectContent>
                                </Select>
                              </td>
                              <td className="px-4 py-3">
                                <div className="flex gap-2">
                                  <Button size="sm" variant="outline">
                                    상세
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* 고객 관리 */}
            <TabsContent value="customers" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>고객 관리</CardTitle>
                  <CardDescription>구매자 정보를 관리합니다</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {customers.map((customer) => (
                      <Card key={customer.id}>
                        <CardContent className="p-6">
                          <div className="grid md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                              <div>
                                <Label>고객명</Label>
                                <Input
                                  value={customer.name}
                                  onChange={(e) => {
                                    const updatedCustomers = customers.map((c) =>
                                      c.id === customer.id ? { ...c, name: e.target.value } : c,
                                    )
                                    setCustomers(updatedCustomers)
                                  }}
                                />
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <Label>전화번호 1</Label>
                                  <Input
                                    value={customer.phone1}
                                    onChange={(e) => {
                                      const updatedCustomers = customers.map((c) =>
                                        c.id === customer.id ? { ...c, phone1: e.target.value } : c,
                                      )
                                      setCustomers(updatedCustomers)
                                    }}
                                  />
                                </div>
                                <div>
                                  <Label>전화번호 2</Label>
                                  <Input
                                    value={customer.phone2 || ""}
                                    placeholder="선택사항"
                                    onChange={(e) => {
                                      const updatedCustomers = customers.map((c) =>
                                        c.id === customer.id ? { ...c, phone2: e.target.value } : c,
                                      )
                                      setCustomers(updatedCustomers)
                                    }}
                                  />
                                </div>
                              </div>
                              <div>
                                <Label>주소</Label>
                                <Input
                                  value={customer.address}
                                  onChange={(e) => {
                                    const updatedCustomers = customers.map((c) =>
                                      c.id === customer.id ? { ...c, address: e.target.value } : c,
                                    )
                                    setCustomers(updatedCustomers)
                                  }}
                                />
                              </div>
                            </div>
                            <div className="space-y-4">
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <Label>주문 횟수</Label>
                                  <Input value={`${customer.order_count}회`} disabled />
                                </div>
                                <div>
                                  <Label>총 구매 금액</Label>
                                  <Input value={`₩${customer.total_spent?.toLocaleString()}`} disabled />
                                </div>
                              </div>
                              <div>
                                <Label>메모</Label>
                                <Textarea
                                  value={customer.memo || ""}
                                  rows={3}
                                  onChange={(e) => {
                                    const updatedCustomers = customers.map((c) =>
                                      c.id === customer.id ? { ...c, memo: e.target.value } : c,
                                    )
                                    setCustomers(updatedCustomers)
                                  }}
                                />
                              </div>
                              <div className="flex gap-2">
                                <Button onClick={() => handleUpdateCustomer(customer.id, customer)}>
                                  <Save className="h-4 w-4 mr-2" />
                                  저장
                                </Button>
                                <Button variant="outline">연락하기</Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* 상담 신청 관리 */}
            <TabsContent value="consultation" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>무료 상담 신청 관리</CardTitle>
                  <CardDescription>상담 신청자 정보를 관리하고 상담 진행 상황을 추적합니다</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {consultationRequests.map((request) => (
                      <Card key={request.id}>
                        <CardContent className="p-6">
                          <div className="grid md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <h3 className="text-lg font-semibold">{request.name}</h3>
                                {getStatusBadge(request.status)}
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <Label>나이</Label>
                                  <Input value={request.age ? `${request.age}세` : "미입력"} disabled />
                                </div>
                                <div>
                                  <Label>연락처</Label>
                                  <Input value={request.phone} disabled />
                                </div>
                              </div>
                              <div>
                                <Label>이메일</Label>
                                <Input value={request.email || "미입력"} disabled />
                              </div>
                              <div>
                                <Label>건강 상태</Label>
                                <Input value={request.health_condition || "미입력"} disabled />
                              </div>
                              <div>
                                <Label>기존 질환</Label>
                                <Input value={request.medical_history?.join(", ") || "없음"} disabled />
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <Label>운동 경험</Label>
                                  <Input value={request.exercise_experience || "미입력"} disabled />
                                </div>
                                <div>
                                  <Label>운동 목표</Label>
                                  <Input value={request.exercise_goal || "미입력"} disabled />
                                </div>
                              </div>
                              <div>
                                <Label>연락 희망 시간</Label>
                                <Input value={request.contact_time || "미입력"} disabled />
                              </div>
                              {request.additional_info && (
                                <div>
                                  <Label>추가 문의사항</Label>
                                  <Textarea value={request.additional_info} disabled rows={3} />
                                </div>
                              )}
                            </div>
                            <div className="space-y-4">
                              <div>
                                <Label>상담 상태</Label>
                                <Select
                                  value={request.status}
                                  onValueChange={(value) => {
                                    const updatedRequests = consultationRequests.map((r) =>
                                      r.id === request.id ? { ...r, status: value } : r,
                                    )
                                    setConsultationRequests(updatedRequests)
                                  }}
                                >
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pending">대기중</SelectItem>
                                    <SelectItem value="contacted">연락완료</SelectItem>
                                    <SelectItem value="completed">상담완료</SelectItem>
                                    <SelectItem value="cancelled">취소</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <Label>관리자 메모</Label>
                                <Textarea
                                  placeholder="상담 내용이나 특이사항을 기록하세요"
                                  rows={4}
                                  value={request.admin_notes || ""}
                                  onChange={(e) => {
                                    const updatedRequests = consultationRequests.map((r) =>
                                      r.id === request.id ? { ...r, admin_notes: e.target.value } : r,
                                    )
                                    setConsultationRequests(updatedRequests)
                                  }}
                                />
                              </div>
                              <div className="bg-gray-50 p-4 rounded-lg">
                                <div className="text-sm text-gray-600 space-y-1">
                                  <p>신청일: {new Date(request.created_at).toLocaleDateString()}</p>
                                  {request.contacted_at && (
                                    <p>연락일: {new Date(request.contacted_at).toLocaleDateString()}</p>
                                  )}
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  onClick={() =>
                                    handleUpdateConsultationRequest(request.id, {
                                      status: request.status,
                                      admin_notes: request.admin_notes,
                                      contacted_at: request.status === "contacted" ? new Date() : undefined,
                                    })
                                  }
                                >
                                  <Save className="h-4 w-4 mr-2" />
                                  저장
                                </Button>
                                <Button variant="outline">
                                  <Phone className="h-4 w-4 mr-2" />
                                  전화걸기
                                </Button>
                                <Button variant="outline">
                                  <Mail className="h-4 w-4 mr-2" />
                                  이메일
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* B2B 제휴 문의 관리 */}
            <TabsContent value="b2b" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>B2B 제휴 문의 관리</CardTitle>
                  <CardDescription>B2B 제휴 문의를 관리하고 답변합니다</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {b2bRequests.map((request) => (
                      <Card key={request.id}>
                        <CardContent className="p-6">
                          <div className="grid md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                              <div className="flex items-center justify-between">
                                <h3 className="text-lg font-semibold">{request.company_name}</h3>
                                {getStatusBadge(request.status)}
                              </div>
                              <div>
                                <Label>담당자 이름</Label>
                                <Input value={request.contact_name} disabled />
                              </div>
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <Label>연락처</Label>
                                  <Input value={request.contact_phone} disabled />
                                </div>
                                <div>
                                  <Label>이메일</Label>
                                  <Input value={request.contact_email} disabled />
                                </div>
                              </div>
                              <div>
                                <Label>문의 유형</Label>
                                <Input value={request.partnership_type || "미입력"} disabled />
                              </div>
                              <div>
                                <Label>타겟 상품</Label>
                                <Input value={request.target_products?.join(", ") || "미입력"} disabled />
                              </div>
                              <div>
                                <Label>예상 물량</Label>
                                <Input value={request.expected_volume || "미입력"} disabled />
                              </div>
                              {request.additional_info && (
                                <div>
                                  <Label>추가 정보</Label>
                                  <Textarea value={request.additional_info} disabled rows={3} />
                                </div>
                              )}
                            </div>
                            <div className="space-y-4">
                              <div>
                                <Label>문의 상태</Label>
                                <Select
                                  value={request.status}
                                  onValueChange={(value) => {
                                    const updatedRequests = b2bRequests.map((r) =>
                                      r.id === request.id ? { ...r, status: value } : r,
                                    )
                                    setB2BRequests(updatedRequests)
                                  }}
                                >
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="pending">대기중</SelectItem>
                                    <SelectItem value="reviewing">검토중</SelectItem>
                                    <SelectItem value="approved">승인</SelectItem>
                                    <SelectItem value="rejected">거절</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div>
                                <Label>답변</Label>
                                <Textarea
                                  placeholder="답변을 입력하세요"
                                  rows={4}
                                  value={request.admin_response || ""}
                                  onChange={(e) => {
                                    const updatedRequests = b2bRequests.map((r) =>
                                      r.id === request.id ? { ...r, admin_response: e.target.value } : r,
                                    )
                                    setB2BRequests(updatedRequests)
                                  }}
                                />
                              </div>
                              <div>
                                <Label>관리자 메모</Label>
                                <Textarea
                                  placeholder="추가 메모를 남겨주세요"
                                  rows={4}
                                  value={request.admin_notes || ""}
                                  onChange={(e) => {
                                    const updatedRequests = b2bRequests.map((r) =>
                                      r.id === request.id ? { ...r, admin_notes: e.target.value } : r,
                                    )
                                    setB2BRequests(updatedRequests)
                                  }}
                                />
                              </div>
                              <div className="bg-gray-50 p-4 rounded-lg">
                                <div className="text-sm text-gray-600 space-y-1">
                                  <p>신청일: {new Date(request.created_at).toLocaleDateString()}</p>
                                  {request.responded_at && (
                                    <p>답변일: {new Date(request.responded_at).toLocaleDateString()}</p>
                                  )}
                                </div>
                              </div>
                              <div className="flex gap-2">
                                <Button
                                  onClick={() =>
                                    handleUpdateB2BRequest(request.id, {
                                      status: request.status,
                                      admin_response: request.admin_response,
                                      admin_notes: request.admin_notes,
                                      responded_at: request.status !== "pending" ? new Date() : undefined,
                                    })
                                  }
                                >
                                  <Save className="h-4 w-4 mr-2" />
                                  저장
                                </Button>
                                <Button variant="outline">
                                  <Mail className="h-4 w-4 mr-2" />
                                  이메일
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Product Detail Modal */}
      <ProductDetailModal
        isOpen={showProductModal}
        onClose={() => setShowProductModal(false)}
        product={selectedProduct}
      />
    </ClientWrapper>
  )
}
