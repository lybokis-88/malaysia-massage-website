"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Heart, Phone, Clock, CheckCircle, User, Calendar } from "lucide-react"

export default function ConsultationPage() {
  const [formSubmitted, setFormSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    phone: "",
    email: "",
    health_condition: "",
    medical_history: [] as string[],
    exercise_experience: "",
    exercise_goal: "",
    additional_info: "",
    contact_time: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const response = await fetch("/api/consultation-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...formData,
          age: formData.age ? Number.parseInt(formData.age) : undefined,
        }),
      })

      if (response.ok) {
        setFormSubmitted(true)
      } else {
        throw new Error("상담 신청 실패")
      }
    } catch (error) {
      console.error("상담 신청 오류:", error)
      alert("상담 신청 중 오류가 발생했습니다. 다시 시도해주세요.")
    }
  }

  const handleMedicalHistoryChange = (condition: string, checked: boolean) => {
    if (checked) {
      setFormData({
        ...formData,
        medical_history: [...formData.medical_history, condition],
      })
    } else {
      setFormData({
        ...formData,
        medical_history: formData.medical_history.filter((item) => item !== condition),
      })
    }
  }

  if (formSubmitted) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <Card className="w-full max-w-md text-center">
          <CardContent className="p-8">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-4">상담 신청 완료</h2>
            <p className="text-gray-600 mb-6">
              상담 신청이 완료되었습니다.
              <br />
              전문 상담사가 24시간 내에 연락드리겠습니다.
            </p>
            <Link href="/">
              <Button className="w-full">홈으로 돌아가기</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link href="/" className="flex items-center">
              <Image src="/images/logo.jpg" alt="이노브로텍 로고" width={40} height={40} className="mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">(주)이노브로텍</h1>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h1 className="text-5xl font-bold mb-6">무료 상담</h1>
          <p className="text-xl leading-relaxed">
            전문 상담사가 어르신의 건강 상태에 맞는 최적의 운동기구를 추천해드립니다
          </p>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Consultation Info */}
          <div>
            <h2 className="text-3xl font-bold text-gray-900 mb-8">왜 상담이 필요한가요?</h2>

            <div className="space-y-6 mb-8">
              <div className="flex items-start">
                <User className="h-6 w-6 text-blue-600 mr-4 mt-1" />
                <div>
                  <h3 className="text-lg font-semibold mb-2">개인 맞춤 추천</h3>
                  <p className="text-gray-600">
                    연령, 건강 상태, 운동 목표에 따라 가장 적합한 운동기구를 추천해드립니다.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <Heart className="h-6 w-6 text-blue-600 mr-4 mt-1" />
                <div>
                  <h3 className="text-lg font-semibold mb-2">안전성 확인</h3>
                  <p className="text-gray-600">
                    기존 질환이나 신체적 제약사항을 고려하여 안전한 운동 방법을 안내합니다.
                  </p>
                </div>
              </div>

              <div className="flex items-start">
                <Calendar className="h-6 w-6 text-blue-600 mr-4 mt-1" />
                <div>
                  <h3 className="text-lg font-semibold mb-2">운동 계획 수립</h3>
                  <p className="text-gray-600">효과적인 운동 스케줄과 강도를 설정하여 꾸준한 운동을 도와드립니다.</p>
                </div>
              </div>
            </div>

            {/* Contact Info */}
            <Card className="bg-blue-50">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Phone className="h-5 w-5 mr-2" />
                  전화 상담
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center">
                    <Phone className="h-4 w-4 mr-2 text-blue-600" />
                    <span className="text-lg font-semibold">1588-0000</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-4 w-4 mr-2 text-blue-600" />
                    <span>평일 09:00 - 18:00</span>
                  </div>
                  <p className="text-sm text-gray-600">급하신 경우 전화로 바로 상담받으실 수 있습니다.</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Consultation Form */}
          <Card>
            <CardHeader>
              <CardTitle className="text-2xl">상담 신청서</CardTitle>
              <CardDescription>정확한 상담을 위해 아래 정보를 입력해주세요</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Personal Info */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">기본 정보</h3>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">이름 *</Label>
                      <Input
                        id="name"
                        required
                        placeholder="홍길동"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="age">나이 *</Label>
                      <Input
                        id="age"
                        type="number"
                        required
                        placeholder="65"
                        value={formData.age}
                        onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="phone">연락처 *</Label>
                      <Input
                        id="phone"
                        required
                        placeholder="010-1234-5678"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">이메일</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="example@email.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                {/* Health Info */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">건강 정보</h3>
                  <div>
                    <Label htmlFor="health-condition">현재 건강 상태</Label>
                    <Select
                      value={formData.health_condition}
                      onValueChange={(value) => setFormData({ ...formData, health_condition: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="건강 상태를 선택하세요" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="excellent">매우 좋음</SelectItem>
                        <SelectItem value="good">좋음</SelectItem>
                        <SelectItem value="fair">보통</SelectItem>
                        <SelectItem value="poor">좋지 않음</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="medical-history">기존 질환 (해당사항 체크)</Label>
                    <div className="grid grid-cols-2 gap-3 mt-2">
                      {["고혈압", "당뇨병", "관절염", "심장질환", "골다공증", "디스크", "기타", "없음"].map(
                        (condition) => (
                          <div key={condition} className="flex items-center space-x-2">
                            <Checkbox
                              id={condition}
                              checked={formData.medical_history.includes(condition)}
                              onCheckedChange={(checked) => handleMedicalHistoryChange(condition, checked as boolean)}
                            />
                            <Label htmlFor={condition} className="text-sm">
                              {condition}
                            </Label>
                          </div>
                        ),
                      )}
                    </div>
                  </div>
                </div>

                {/* Exercise Info */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">운동 정보</h3>
                  <div>
                    <Label htmlFor="exercise-experience">운동 경험</Label>
                    <Select
                      value={formData.exercise_experience}
                      onValueChange={(value) => setFormData({ ...formData, exercise_experience: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="운동 경험을 선택하세요" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">운동 경험 없음</SelectItem>
                        <SelectItem value="beginner">초보자</SelectItem>
                        <SelectItem value="intermediate">중급자</SelectItem>
                        <SelectItem value="advanced">상급자</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="exercise-goal">운동 목표</Label>
                    <Select
                      value={formData.exercise_goal}
                      onValueChange={(value) => setFormData({ ...formData, exercise_goal: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="운동 목표를 선택하세요" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="health">건강 유지</SelectItem>
                        <SelectItem value="strength">근력 강화</SelectItem>
                        <SelectItem value="balance">균형감각 향상</SelectItem>
                        <SelectItem value="flexibility">유연성 향상</SelectItem>
                        <SelectItem value="weight">체중 관리</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Additional Info */}
                <div>
                  <Label htmlFor="additional-info">추가 문의사항</Label>
                  <Textarea
                    id="additional-info"
                    placeholder="궁금한 점이나 특별히 고려해야 할 사항이 있으시면 적어주세요"
                    rows={4}
                    value={formData.additional_info}
                    onChange={(e) => setFormData({ ...formData, additional_info: e.target.value })}
                  />
                </div>

                {/* Preferred Contact */}
                <div>
                  <Label htmlFor="contact-time">연락 희망 시간</Label>
                  <Select
                    value={formData.contact_time}
                    onValueChange={(value) => setFormData({ ...formData, contact_time: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="연락 희망 시간을 선택하세요" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="morning">오전 (09:00-12:00)</SelectItem>
                      <SelectItem value="afternoon">오후 (12:00-18:00)</SelectItem>
                      <SelectItem value="evening">저녁 (18:00-21:00)</SelectItem>
                      <SelectItem value="anytime">언제든지</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Privacy Agreement */}
                <div className="flex items-center space-x-2">
                  <Checkbox id="privacy" required />
                  <Label htmlFor="privacy" className="text-sm">
                    개인정보 수집 및 이용에 동의합니다 *
                  </Label>
                </div>

                <Button type="submit" className="w-full text-lg py-4 h-auto">
                  무료 상담 신청하기
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
