import Image from "next/image"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Award, Users, Target, Heart } from "lucide-react"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <div className="flex items-center">
              <Image src="/images/logo.jpg" alt="이노브로텍 로고" width={40} height={40} className="mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">(주)이노브로텍</h1>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h1 className="text-5xl font-bold mb-6">회사소개</h1>
          <p className="text-xl leading-relaxed">건강한 노후를 위한 맞춤형 운동기구 전문업체 (주)이노브로텍입니다</p>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">(주)이노브로텍의 시작</h2>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                2020년, 고령화 사회에서 어르신들의 건강한 노후를 위해 시작된 (주)이노브로텍은 60세 이상 어르신들을 위한
                전용 운동기구를 개발하고 있습니다.
              </p>
              <p className="text-lg text-gray-600 mb-6 leading-relaxed">
                일반적인 운동기구와 달리, 어르신들의 신체적 특성과 안전성을 최우선으로 고려하여 설계된 제품들로 많은
                어르신들의 건강한 일상을 돕고 있습니다.
              </p>
              <p className="text-lg text-gray-600 leading-relaxed">
                현재까지 전국 5,000여 가정에 제품을 공급하며, 어르신들의 건강 증진에 기여하고 있습니다.
              </p>
            </div>
            <div className="relative">
              <Image
                src="/placeholder.svg?height=400&width=600"
                alt="시니어핏 사무실"
                width={600}
                height={400}
                className="rounded-lg shadow-lg"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">미션 & 비전</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <Card className="text-center p-8">
              <CardHeader>
                <Target className="h-16 w-16 text-blue-600 mx-auto mb-4" />
                <CardTitle className="text-2xl">미션</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg text-gray-600 leading-relaxed">
                  어르신들이 안전하고 즐겁게 운동할 수 있는 환경을 조성하여 건강한 노후 생활을 지원합니다.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center p-8">
              <CardHeader>
                <Heart className="h-16 w-16 text-blue-600 mx-auto mb-4" />
                <CardTitle className="text-2xl">비전</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-lg text-gray-600 leading-relaxed">
                  시니어 헬스케어 분야의 선도기업으로서 모든 어르신들이 활기찬 노후를 보낼 수 있도록 돕겠습니다.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Core Values */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">핵심 가치</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <Award className="h-16 w-16 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">안전성</h3>
              <p className="text-gray-600 leading-relaxed">어르신들의 안전을 최우선으로 하는 제품 설계와 서비스 제공</p>
            </div>
            <div className="text-center">
              <Users className="h-16 w-16 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">전문성</h3>
              <p className="text-gray-600 leading-relaxed">
                시니어 헬스케어 전문가들의 연구와 개발을 통한 최적의 솔루션 제공
              </p>
            </div>
            <div className="text-center">
              <Heart className="h-16 w-16 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">신뢰성</h3>
              <p className="text-gray-600 leading-relaxed">고객과의 약속을 지키며 지속적인 관리와 서비스로 신뢰 구축</p>
            </div>
          </div>
        </div>
      </section>

      {/* Company Info */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">회사 정보</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">기업 개요</h3>
              <ul className="space-y-3 text-gray-600">
                <li>
                  <strong>회사명:</strong> (주)이노브로텍
                </li>
                <li>
                  <strong>설립일:</strong> 2020년 3월
                </li>
                <li>
                  <strong>대표이사:</strong> 김건강
                </li>
                <li>
                  <strong>직원 수:</strong> 25명
                </li>
                <li>
                  <strong>자본금:</strong> 10억원
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">연락처</h3>
              <ul className="space-y-3 text-gray-600">
                <li>
                  <strong>본사:</strong> 서울시 강남구 테헤란로 123
                </li>
                <li>
                  <strong>전화:</strong> 1588-0000
                </li>
                <li>
                  <strong>팩스:</strong> 02-1234-5678
                </li>
                <li>
                  <strong>이메일:</strong> info@innovrotech.co.kr
                </li>
                <li>
                  <strong>홈페이지:</strong> www.innovrotech.co.kr
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
