import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star, Shield, Award } from "lucide-react"

export default function ProductsPage() {
  const products = [
    {
      id: 1,
      name: "실버 워킹머신",
      price: "299,000원",
      originalPrice: "349,000원",
      description:
        "저강도 운동으로 안전하게 걷기 운동을 할 수 있는 워킹머신입니다. 관절에 무리가 가지 않는 설계로 매일 꾸준한 유산소 운동이 가능합니다.",
      image: "/placeholder.svg?height=400&width=500",
      features: ["안전 손잡이", "속도 조절 (0.5-6km/h)", "심박수 측정", "LCD 디스플레이", "접이식 설계"],
      benefits: ["심폐기능 향상", "하체 근력 강화", "균형감각 개선"],
      rating: 4.8,
      reviews: 156,
      badge: "베스트셀러",
    },
    {
      id: 2,
      name: "시니어 스트레칭 체어",
      price: "189,000원",
      originalPrice: "229,000원",
      description:
        "앉아서 편안하게 전신 스트레칭이 가능한 전용 의자입니다. 관절 가동범위를 늘리고 근육의 유연성을 향상시킵니다.",
      image: "/placeholder.svg?height=400&width=500",
      features: ["등받이 각도 조절", "팔걸이 스트레칭", "발목 운동 기능", "쿠션 시트", "안전벨트"],
      benefits: ["관절 유연성 향상", "혈액순환 개선", "근육 이완"],
      rating: 4.7,
      reviews: 89,
      badge: "신제품",
    },
    {
      id: 3,
      name: "균형감각 트레이너",
      price: "149,000원",
      originalPrice: "179,000원",
      description:
        "균형감각 향상과 낙상 예방을 위한 안전한 운동기구입니다. 단계별 훈련으로 안전하게 균형감각을 기를 수 있습니다.",
      image: "/placeholder.svg?height=400&width=500",
      features: ["안전 바 (높이 조절)", "미끄럼 방지 패드", "단계별 훈련 가이드", "각도 조절", "접이식 보관"],
      benefits: ["낙상 예방", "코어 근력 강화", "자세 교정"],
      rating: 4.9,
      reviews: 203,
      badge: "추천",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link href="/" className="flex items-center">
              <Image src="/images/logo.jpg" alt="이노브로텍 로고" width={40} height={40} className="mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">(주)이노브로텍</h1>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h1 className="text-5xl font-bold mb-6">제품 소개</h1>
          <p className="text-xl leading-relaxed">어르신들을 위해 특별히 설계된 안전하고 효과적인 운동기구</p>
        </div>
      </section>

      {/* Products Grid */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid gap-12">
            {products.map((product, index) => (
              <Card key={product.id} className="overflow-hidden shadow-lg">
                <div className={`grid lg:grid-cols-2 gap-8 ${index % 2 === 1 ? "lg:grid-flow-col-dense" : ""}`}>
                  <div className={`relative ${index % 2 === 1 ? "lg:col-start-2" : ""}`}>
                    <Image
                      src={product.image || "/placeholder.svg"}
                      alt={product.name}
                      width={500}
                      height={400}
                      className="w-full h-full object-cover"
                    />
                    {product.badge && (
                      <Badge className="absolute top-4 left-4 bg-red-500 text-white text-sm px-3 py-1">
                        {product.badge}
                      </Badge>
                    )}
                  </div>
                  <div className={`p-8 ${index % 2 === 1 ? "lg:col-start-1" : ""}`}>
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex items-center">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`h-5 w-5 ${
                              i < Math.floor(product.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-sm text-gray-600">
                        {product.rating} ({product.reviews}개 리뷰)
                      </span>
                    </div>

                    <h2 className="text-3xl font-bold text-gray-900 mb-4">{product.name}</h2>

                    <p className="text-lg text-gray-600 mb-6 leading-relaxed">{product.description}</p>

                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-3 flex items-center">
                        <Shield className="h-5 w-5 mr-2 text-blue-600" />
                        주요 기능
                      </h3>
                      <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {product.features.map((feature, idx) => (
                          <li key={idx} className="text-gray-600 flex items-center">
                            <span className="w-2 h-2 bg-blue-600 rounded-full mr-3"></span>
                            {feature}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mb-6">
                      <h3 className="text-lg font-semibold mb-3 flex items-center">
                        <Award className="h-5 w-5 mr-2 text-green-600" />
                        운동 효과
                      </h3>
                      <ul className="flex flex-wrap gap-2">
                        {product.benefits.map((benefit, idx) => (
                          <Badge key={idx} variant="secondary" className="text-sm">
                            {benefit}
                          </Badge>
                        ))}
                      </ul>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <div className="flex items-center gap-3">
                          <span className="text-3xl font-bold text-blue-600">{product.price}</span>
                          <span className="text-lg text-gray-500 line-through">{product.originalPrice}</span>
                        </div>
                        <p className="text-sm text-green-600 font-medium">무료배송 • 설치서비스 포함</p>
                      </div>
                      <Link href={`/product/${product.id}`}>
                        <Button size="lg" className="text-lg px-8 py-4 h-auto">
                          구매하기
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-blue-50">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">어떤 제품이 맞는지 고민되시나요?</h2>
          <p className="text-lg text-gray-600 mb-8">
            전문 상담사가 어르신의 건강 상태와 운동 목표에 맞는 최적의 제품을 추천해드립니다
          </p>
          <Link href="/consultation">
            <Button size="lg" className="text-lg px-8 py-4 h-auto">
              무료 상담 받기
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}
