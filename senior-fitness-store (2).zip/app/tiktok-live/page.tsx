"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Heart, Video, Clock, Users, Gift, Star, Play, Calendar } from "lucide-react"

export default function TikTokLivePage() {
  const [isLive, setIsLive] = useState(true)

  const upcomingShows = [
    {
      id: 1,
      title: "실버 워킹머신 체험 라이브",
      date: "2024년 1월 15일",
      time: "오후 2시",
      host: "김건강 트레이너",
      viewers: "예상 500명",
      specialOffer: "라이브 한정 20% 할인",
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 2,
      title: "시니어 스트레칭 따라하기",
      date: "2024년 1월 17일",
      time: "오전 10시",
      host: "박유연 강사",
      viewers: "예상 300명",
      specialOffer: "무료 상담 + 사은품",
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 3,
      title: "균형감각 운동 클래스",
      date: "2024년 1월 20일",
      time: "오후 3시",
      host: "이균형 전문가",
      viewers: "예상 400명",
      specialOffer: "체험단 모집",
      thumbnail: "/placeholder.svg?height=200&width=300",
    },
  ]

  const pastShows = [
    {
      id: 1,
      title: "신년 건강 다짐 특집",
      date: "2024년 1월 10일",
      views: "1,234회",
      likes: "156개",
      thumbnail: "/placeholder.svg?height=150&width=200",
    },
    {
      id: 2,
      title: "겨울철 실내 운동법",
      date: "2024년 1월 8일",
      views: "987회",
      likes: "98개",
      thumbnail: "/placeholder.svg?height=150&width=200",
    },
    {
      id: 3,
      title: "제품 사용법 완전 정복",
      date: "2024년 1월 5일",
      views: "2,156회",
      likes: "234개",
      thumbnail: "/placeholder.svg?height=150&width=200",
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link href="/" className="flex items-center">
              <Image src="/images/logo.jpg" alt="이노브로텍 로고" width={40} height={40} className="mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">(주)이노브로텍</h1>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h1 className="text-5xl font-bold mb-6">틱톡 라이브</h1>
          <p className="text-xl leading-relaxed mb-8">전문가와 함께하는 실시간 운동 클래스와 제품 체험</p>
          {isLive && (
            <div className="flex items-center justify-center gap-4 mb-6">
              <Badge className="bg-red-500 text-white text-lg px-4 py-2 animate-pulse">🔴 LIVE</Badge>
              <span className="text-lg">지금 라이브 방송 중!</span>
            </div>
          )}
          <Button size="lg" className="text-lg px-8 py-4 h-auto bg-white text-purple-600 hover:bg-gray-100">
            <Video className="mr-2 h-5 w-5" />
            틱톡에서 보기
          </Button>
        </div>
      </section>

      {/* Current Live Stream */}
      {isLive && (
        <section className="py-16">
          <div className="max-w-4xl mx-auto px-4">
            <Card className="overflow-hidden shadow-xl">
              <div className="relative">
                <div className="aspect-video bg-gray-900 flex items-center justify-center">
                  <div className="text-center text-white">
                    <Play className="h-20 w-20 mx-auto mb-4 opacity-80" />
                    <p className="text-xl mb-2">실버 워킹머신 체험 라이브</p>
                    <p className="text-sm opacity-80">김건강 트레이너와 함께</p>
                  </div>
                </div>
                <Badge className="absolute top-4 left-4 bg-red-500 text-white animate-pulse">🔴 LIVE</Badge>
                <div className="absolute bottom-4 right-4 bg-black bg-opacity-50 text-white px-3 py-1 rounded">
                  <Users className="inline h-4 w-4 mr-1" />
                  342명 시청 중
                </div>
              </div>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-2xl font-bold">실버 워킹머신 체험 라이브</h2>
                  <Badge variant="secondary" className="text-sm">
                    <Gift className="h-4 w-4 mr-1" />
                    라이브 한정 20% 할인
                  </Badge>
                </div>
                <p className="text-gray-600 mb-4">
                  김건강 트레이너와 함께 실버 워킹머신의 올바른 사용법을 배우고, 실제 어르신들의 체험 후기를 들어보세요!
                </p>
                <div className="flex gap-4">
                  <Button className="flex-1">
                    <Video className="mr-2 h-4 w-4" />
                    틱톡에서 참여하기
                  </Button>
                  <Button variant="outline">
                    <Heart className="mr-2 h-4 w-4" />
                    알림 설정
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      )}

      {/* Upcoming Shows */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">예정된 라이브 방송</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {upcomingShows.map((show) => (
              <Card key={show.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-video relative">
                  <Image src={show.thumbnail || "/placeholder.svg"} alt={show.title} fill className="object-cover" />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
                    <Calendar className="h-12 w-12 text-white" />
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{show.title}</CardTitle>
                  <CardDescription>
                    <div className="space-y-1">
                      <div className="flex items-center text-sm">
                        <Clock className="h-4 w-4 mr-1" />
                        {show.date} {show.time}
                      </div>
                      <div className="flex items-center text-sm">
                        <Users className="h-4 w-4 mr-1" />
                        진행: {show.host}
                      </div>
                    </div>
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Badge variant="secondary" className="w-full justify-center">
                      <Gift className="h-4 w-4 mr-1" />
                      {show.specialOffer}
                    </Badge>
                    <Button className="w-full bg-transparent" variant="outline">
                      알림 설정하기
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Past Shows */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">지난 방송 다시보기</h2>
          <div className="grid md:grid-cols-3 gap-6">
            {pastShows.map((show) => (
              <Card key={show.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
                <div className="aspect-video relative">
                  <Image src={show.thumbnail || "/placeholder.svg"} alt={show.title} fill className="object-cover" />
                  <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
                    <Play className="h-12 w-12 text-white" />
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{show.title}</CardTitle>
                  <CardDescription>{show.date}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-gray-600">
                    <div className="flex items-center">
                      <Video className="h-4 w-4 mr-1" />
                      {show.views}
                    </div>
                    <div className="flex items-center">
                      <Heart className="h-4 w-4 mr-1" />
                      {show.likes}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="text-center mt-8">
            <Button variant="outline" size="lg">
              더 많은 영상 보기
            </Button>
          </div>
        </div>
      </section>

      {/* Live Benefits */}
      <section className="py-16 bg-purple-50">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">틱톡 라이브만의 특별한 혜택</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center">
              <Gift className="h-16 w-16 text-purple-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">라이브 한정 할인</h3>
              <p className="text-gray-600">라이브 방송 중에만 제공되는 특별 할인 혜택</p>
            </div>
            <div className="text-center">
              <Users className="h-16 w-16 text-purple-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">실시간 소통</h3>
              <p className="text-gray-600">전문가와 실시간으로 질문하고 답변받기</p>
            </div>
            <div className="text-center">
              <Star className="h-16 w-16 text-purple-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-3">체험단 모집</h3>
              <p className="text-gray-600">라이브 시청자 대상 무료 체험 기회 제공</p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl font-bold mb-6">
            (주)이노브로텍 틱톡 팔로우하고
            <br />
            라이브 알림 받기
          </h2>
          <p className="text-xl mb-8">매주 새로운 운동 클래스와 제품 체험 라이브가 진행됩니다</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="text-lg px-8 py-4 h-auto bg-white text-purple-600 hover:bg-gray-100">
              <Video className="mr-2 h-5 w-5" />
              틱톡 팔로우하기
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="text-lg px-8 py-4 h-auto border-white text-white hover:bg-white hover:text-purple-600 bg-transparent"
            >
              알림 설정하기
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
