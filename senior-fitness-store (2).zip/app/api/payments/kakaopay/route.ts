import { type NextRequest, NextResponse } from "next/server"

// 카카오페이 결제 준비
export async function POST(request: NextRequest) {
  try {
    const { order_id, payment_id, amount, item_name } = await request.json()

    const kakaoResponse = await fetch("https://kapi.kakao.com/v1/payment/ready", {
      method: "POST",
      headers: {
        Authorization: `KakaoAK ${process.env.KAKAO_ADMIN_KEY}`,
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
      },
      body: new URLSearchParams({
        cid: process.env.KAKAO_CID!,
        partner_order_id: `order-${order_id}`,
        partner_user_id: `user-${order_id}`,
        item_name,
        quantity: "1",
        total_amount: amount.toString(),
        tax_free_amount: "0",
        approval_url: `${process.env.NEXT_PUBLIC_BASE_URL}/payment/success?payment_id=${payment_id}`,
        cancel_url: `${process.env.NEXT_PUBLIC_BASE_URL}/payment/cancel?payment_id=${payment_id}`,
        fail_url: `${process.env.NEXT_PUBLIC_BASE_URL}/payment/fail?payment_id=${payment_id}`,
      }),
    })

    const kakaoResult = await kakaoResponse.json()

    if (kakaoResponse.ok) {
      return NextResponse.json({
        success: true,
        redirect_url: kakaoResult.next_redirect_pc_url,
        tid: kakaoResult.tid,
      })
    } else {
      return NextResponse.json({ success: false, error: kakaoResult.msg }, { status: 400 })
    }
  } catch (error) {
    console.error("KakaoPay preparation error:", error)
    return NextResponse.json({ success: false, error: "카카오페이 결제 준비 중 오류가 발생했습니다." }, { status: 500 })
  }
}
