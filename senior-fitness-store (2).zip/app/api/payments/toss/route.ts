import { type NextRequest, NextResponse } from "next/server"
import { updatePaymentStatus } from "@/lib/payment"

// 토스페이먼츠 결제 승인
export async function POST(request: NextRequest) {
  try {
    const { paymentKey, orderId, amount } = await request.json()

    // 토스페이먼츠 API 호출
    const tossResponse = await fetch("https://api.tosspayments.com/v1/payments/confirm", {
      method: "POST",
      headers: {
        Authorization: `Basic ${Buffer.from(process.env.TOSS_SECRET_KEY + ":").toString("base64")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        paymentKey,
        orderId,
        amount,
      }),
    })

    const tossResult = await tossResponse.json()

    if (tossResponse.ok) {
      // 결제 성공 - DB 업데이트
      await updatePaymentStatus(
        Number.parseInt(orderId.split("-")[1]), // payment_id 추출
        "completed",
        paymentKey,
      )

      return NextResponse.json({
        success: true,
        message: "결제가 완료되었습니다.",
        data: tossResult,
      })
    } else {
      // 결제 실패
      await updatePaymentStatus(Number.parseInt(orderId.split("-")[1]), "failed", undefined, tossResult.message)

      return NextResponse.json({ success: false, error: tossResult.message }, { status: 400 })
    }
  } catch (error) {
    console.error("Payment confirmation error:", error)
    return NextResponse.json({ success: false, error: "결제 처리 중 오류가 발생했습니다." }, { status: 500 })
  }
}
