import { type NextRequest, NextResponse } from "next/server"
import { updateCompanyInfo, deleteCompanyInfo } from "@/lib/admin-database"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const data = await request.json()
    const companyInfo = await updateCompanyInfo(Number.parseInt(params.id), data)
    return NextResponse.json(companyInfo)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update company info" }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    await deleteCompanyInfo(Number.parseInt(params.id))
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: "Failed to delete company info" }, { status: 500 })
  }
}
