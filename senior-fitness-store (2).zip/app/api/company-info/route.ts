import { type NextRequest, NextResponse } from "next/server"
import { getCompanyInfo, createCompanyInfo } from "@/lib/admin-database"

export async function GET() {
  try {
    const companyInfo = await getCompanyInfo()
    return NextResponse.json(companyInfo)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch company info" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const companyInfo = await createCompanyInfo(data)
    return NextResponse.json(companyInfo)
  } catch (error) {
    return NextResponse.json({ error: "Failed to create company info" }, { status: 500 })
  }
}
