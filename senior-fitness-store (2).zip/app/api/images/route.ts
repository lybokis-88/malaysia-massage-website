import { type NextRequest, NextResponse } from "next/server"
import { getImages, createImage } from "@/lib/database"

export async function GET() {
  try {
    const images = await getImages()
    return NextResponse.json(images)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch images" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const image = await createImage(data)
    return NextResponse.json(image)
  } catch (error) {
    return NextResponse.json({ error: "Failed to create image" }, { status: 500 })
  }
}
