import { type NextRequest, NextResponse } from "next/server"
import { updateProduct } from "@/lib/database"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const data = await request.json()
    const product = await updateProduct(Number.parseInt(params.id), data)
    return NextResponse.json(product)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update product" }, { status: 500 })
  }
}
