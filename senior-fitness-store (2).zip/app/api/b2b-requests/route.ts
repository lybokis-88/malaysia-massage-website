import { type NextRequest, NextResponse } from "next/server"
import { getB2BRequests, createB2BRequest } from "@/lib/admin-database"

export async function GET() {
  try {
    const requests = await getB2BRequests()
    return NextResponse.json(requests)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch B2B requests" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const b2bRequest = await createB2BRequest(data)
    return NextResponse.json(b2bRequest)
  } catch (error) {
    return NextResponse.json({ error: "Failed to create B2B request" }, { status: 500 })
  }
}
