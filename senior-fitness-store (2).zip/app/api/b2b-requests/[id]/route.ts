import { type NextRequest, NextResponse } from "next/server"
import { updateB2BRequest } from "@/lib/admin-database"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const data = await request.json()
    const b2bRequest = await updateB2BRequest(Number.parseInt(params.id), data)
    return NextResponse.json(b2bRequest)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update B2B request" }, { status: 500 })
  }
}
