import { type NextRequest, NextResponse } from "next/server"
import { updateCustomer } from "@/lib/database"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const data = await request.json()
    const customer = await updateCustomer(Number.parseInt(params.id), data)
    return NextResponse.json(customer)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update customer" }, { status: 500 })
  }
}
