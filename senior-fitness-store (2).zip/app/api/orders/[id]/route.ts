import { type NextRequest, NextResponse } from "next/server"
import { updateOrderStatus, getOrderById } from "@/lib/database"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { status } = await request.json()
    const order = await updateOrderStatus(Number.parseInt(params.id), status)
    return NextResponse.json(order)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update order" }, { status: 500 })
  }
}

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const order = await getOrderById(Number.parseInt(params.id))
    if (order) {
      return NextResponse.json(order)
    } else {
      return NextResponse.json({ error: "주문을 찾을 수 없습니다." }, { status: 404 })
    }
  } catch (error) {
    return NextResponse.json({ error: "주문 조회에 실패했습니다." }, { status: 500 })
  }
}
