import { type NextRequest, NextResponse } from "next/server"
import { createOrder, createPayment } from "@/lib/payment"

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()

    // 주문 생성
    const order = await createOrder({
      product_id: data.product_id,
      quantity: data.quantity,
      total_amount: data.total_amount,
      payment_method: data.payment_method,
      customer_info: data.customer_info,
      shipping_info: data.shipping_info,
    })

    // 결제 정보 생성
    const payment = await createPayment({
      order_id: order.id,
      payment_method: data.payment_method,
      payment_provider: data.payment_provider,
      amount: data.total_amount,
    })

    return NextResponse.json({
      success: true,
      order_id: order.id,
      payment_id: payment.id,
      message: "주문이 생성되었습니다.",
    })
  } catch (error) {
    console.error("Order creation error:", error)
    return NextResponse.json({ success: false, error: "주문 생성에 실패했습니다." }, { status: 500 })
  }
}
