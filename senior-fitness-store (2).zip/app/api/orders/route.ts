import { type NextRequest, NextResponse } from "next/server"
import { getOrders, getOrderStats } from "@/lib/database"

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const stats = searchParams.get("stats")

    if (stats === "true") {
      const orderStats = await getOrderStats()
      return NextResponse.json(orderStats)
    }

    const orders = await getOrders()
    return NextResponse.json(orders)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch orders" }, { status: 500 })
  }
}
