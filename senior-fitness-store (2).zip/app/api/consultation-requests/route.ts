import { type NextRequest, NextResponse } from "next/server"
import { getConsultationRequests, createConsultationRequest } from "@/lib/admin-database"

export async function GET() {
  try {
    const requests = await getConsultationRequests()
    return NextResponse.json(requests)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch consultation requests" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const data = await request.json()
    const consultationRequest = await createConsultationRequest(data)
    return NextResponse.json(consultationRequest)
  } catch (error) {
    return NextResponse.json({ error: "Failed to create consultation request" }, { status: 500 })
  }
}
