import { type NextRequest, NextResponse } from "next/server"
import { updateConsultationRequest } from "@/lib/admin-database"

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const data = await request.json()
    const consultationRequest = await updateConsultationRequest(Number.parseInt(params.id), data)
    return NextResponse.json(consultationRequest)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update consultation request" }, { status: 500 })
  }
}
