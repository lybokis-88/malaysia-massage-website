import { type NextRequest, NextResponse } from "next/server"
import { getFooterInfo, updateFooterInfo } from "@/lib/database"

export async function GET() {
  try {
    const footerInfo = await getFooterInfo()
    return NextResponse.json(footerInfo)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch footer info" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const data = await request.json()
    const footerInfo = await updateFooterInfo(data)
    return NextResponse.json(footerInfo)
  } catch (error) {
    return NextResponse.json({ error: "Failed to update footer info" }, { status: 500 })
  }
}
