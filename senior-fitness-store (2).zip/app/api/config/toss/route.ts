import { NextResponse } from "next/server"

/**
 * Returns the Toss Payments client key without exposing it at build-time.
 * The client fetches this value at runtime via XHR/fetch.
 */
export async function GET() {
  // NOTE: use a *private* env variable to ensure the key is never in the client bundle
  const clientKey = process.env.TOSS_CLIENT_KEY

  if (!clientKey) {
    return NextResponse.json({ error: "Missing client key" }, { status: 500 })
  }

  return NextResponse.json({ clientKey })
}
