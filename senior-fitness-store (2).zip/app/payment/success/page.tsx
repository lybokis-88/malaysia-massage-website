"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, Package, Phone } from "lucide-react"

export default function PaymentSuccessPage() {
  const searchParams = useSearchParams()
  const [orderInfo, setOrderInfo] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const confirmPayment = async () => {
      const paymentKey = searchParams.get("paymentKey")
      const orderId = searchParams.get("orderId")
      const amount = searchParams.get("amount")

      if (paymentKey && orderId && amount) {
        try {
          const response = await fetch("/api/payments/toss", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ paymentKey, orderId, amount }),
          })

          const result = await response.json()

          if (result.success) {
            // 주문 정보 조회
            const orderResponse = await fetch(`/api/orders/${orderId.split("-")[1]}`)
            const orderData = await orderResponse.json()
            setOrderInfo(orderData)
          }
        } catch (error) {
          console.error("Payment confirmation error:", error)
        }
      }
      setLoading(false)
    }

    confirmPayment()
  }, [searchParams])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p>결제를 확인하고 있습니다...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
          <CardTitle className="text-2xl text-green-600">결제가 완료되었습니다!</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {orderInfo && (
            <div className="bg-gray-50 p-4 rounded-lg space-y-3">
              <h3 className="font-semibold text-lg">주문 정보</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">주문번호:</span>
                  <span className="font-medium ml-2">#{orderInfo.id.toString().padStart(6, "0")}</span>
                </div>
                <div>
                  <span className="text-gray-600">상품명:</span>
                  <span className="font-medium ml-2">{orderInfo.product_name}</span>
                </div>
                <div>
                  <span className="text-gray-600">결제금액:</span>
                  <span className="font-medium ml-2">₩{orderInfo.total_amount?.toLocaleString()}</span>
                </div>
                <div>
                  <span className="text-gray-600">배송지:</span>
                  <span className="font-medium ml-2">{orderInfo.shipping_address}</span>
                </div>
              </div>
            </div>
          )}

          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="font-semibold text-blue-800 mb-2">다음 단계</h4>
            <ul className="text-sm text-blue-700 space-y-1">
              <li>• 주문 확인 후 1-2일 내에 배송이 시작됩니다</li>
              <li>• 설치 서비스는 배송일에 함께 진행됩니다</li>
              <li>• 배송 전 담당자가 연락드릴 예정입니다</li>
            </ul>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Link href="/" className="flex-1">
              <Button variant="outline" className="w-full bg-transparent">
                홈으로 돌아가기
              </Button>
            </Link>
            <Button className="flex-1">
              <Package className="mr-2 h-4 w-4" />
              주문 조회
            </Button>
            <Button variant="outline" className="flex-1 bg-transparent">
              <Phone className="mr-2 h-4 w-4" />
              고객센터
            </Button>
          </div>

          <div className="text-center text-sm text-gray-600">
            <p>문의사항이 있으시면 고객센터(1588-0000)로 연락주세요.</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
