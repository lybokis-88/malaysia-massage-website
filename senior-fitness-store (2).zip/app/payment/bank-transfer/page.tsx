"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Building, Copy, Phone, CheckCircle } from "lucide-react"
import { useToast } from "@/hooks/use-toast"

export default function BankTransferPage() {
  const searchParams = useSearchParams()
  const { toast } = useToast()
  const [orderInfo, setOrderInfo] = useState<any>(null)
  const orderId = searchParams.get("order_id")

  const bankInfo = {
    bank: "국민은행",
    account: "123-456-789012",
    holder: "(주)이노브로텍",
  }

  useEffect(() => {
    if (orderId) {
      // 주문 정보 조회
      fetch(`/api/orders/${orderId}`)
        .then((res) => res.json())
        .then((data) => setOrderInfo(data))
        .catch(console.error)
    }
  }, [orderId])

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    toast({
      title: "복사 완료",
      description: "계좌번호가 클립보드에 복사되었습니다.",
    })
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <Building className="h-16 w-16 text-blue-500 mx-auto mb-4" />
          <CardTitle className="text-2xl text-blue-600">무통장입금 안내</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {orderInfo && (
            <div className="bg-gray-50 p-4 rounded-lg space-y-3">
              <h3 className="font-semibold text-lg">주문 정보</h3>
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-600">주문번호:</span>
                  <span className="font-medium ml-2">#{orderInfo.id.toString().padStart(6, "0")}</span>
                </div>
                <div>
                  <span className="text-gray-600">상품명:</span>
                  <span className="font-medium ml-2">{orderInfo.product_name}</span>
                </div>
                <div>
                  <span className="text-gray-600">입금금액:</span>
                  <span className="font-medium ml-2 text-lg text-red-600">
                    ₩{orderInfo.total_amount?.toLocaleString()}
                  </span>
                </div>
                <div>
                  <span className="text-gray-600">주문자:</span>
                  <span className="font-medium ml-2">{orderInfo.customer_name}</span>
                </div>
              </div>
            </div>
          )}

          <div className="bg-blue-50 p-6 rounded-lg">
            <h3 className="font-semibold text-lg mb-4 text-blue-800">입금 계좌 정보</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">은행명:</span>
                <span className="font-bold text-lg">{bankInfo.bank}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">계좌번호:</span>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-lg">{bankInfo.account}</span>
                  <Button size="sm" variant="outline" onClick={() => copyToClipboard(bankInfo.account)}>
                    <Copy className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-600">예금주:</span>
                <span className="font-bold text-lg">{bankInfo.holder}</span>
              </div>
            </div>
          </div>

          <div className="bg-yellow-50 p-4 rounded-lg">
            <h4 className="font-semibold text-yellow-800 mb-2 flex items-center">
              <CheckCircle className="h-5 w-5 mr-2" />
              입금 시 주의사항
            </h4>
            <ul className="text-sm text-yellow-700 space-y-1">
              <li>• 입금자명은 주문자명과 동일하게 해주세요</li>
              <li>• 입금 확인 후 1-2일 내에 배송이 시작됩니다</li>
              <li>• 주문일로부터 3일 이내 미입금시 주문이 자동 취소됩니다</li>
              <li>• 입금 완료 후 고객센터로 연락주시면 빠른 처리가 가능합니다</li>
            </ul>
          </div>

          <div className="text-center">
            <Badge variant="secondary" className="text-sm px-4 py-2">
              입금 확인은 평일 09:00-18:00에 처리됩니다
            </Badge>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Link href="/" className="flex-1">
              <Button variant="outline" className="w-full bg-transparent">
                홈으로 돌아가기
              </Button>
            </Link>
            <Button className="flex-1">
              <Phone className="mr-2 h-4 w-4" />
              입금 확인 문의 (1588-0000)
            </Button>
          </div>

          <div className="text-center text-sm text-gray-600">
            <p>입금 관련 문의: 평일 09:00-18:00 / 1588-0000</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
