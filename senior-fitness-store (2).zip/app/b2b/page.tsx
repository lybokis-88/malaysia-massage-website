"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Building, Users, TrendingUp, Award, CheckCircle, Handshake } from "lucide-react"

export default function B2BPage() {
  const [formSubmitted, setFormSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    company_name: "",
    business_type: "",
    company_size: "",
    annual_revenue: "",
    contact_name: "",
    contact_position: "",
    contact_phone: "",
    contact_email: "",
    partnership_type: "",
    target_products: [] as string[],
    expected_volume: "",
    additional_info: "",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const response = await fetch("/api/b2b-requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      })

      if (response.ok) {
        setFormSubmitted(true)
      } else {
        throw new Error("B2B 제휴 문의 실패")
      }
    } catch (error) {
      console.error("B2B 제휴 문의 오류:", error)
      alert("제휴 문의 중 오류가 발생했습니다. 다시 시도해주세요.")
    }
  }

  const handleProductChange = (product: string, checked: boolean) => {
    if (checked) {
      setFormData({
        ...formData,
        target_products: [...formData.target_products, product],
      })
    } else {
      setFormData({
        ...formData,
        target_products: formData.target_products.filter((item) => item !== product),
      })
    }
  }

  const benefits = [
    {
      icon: TrendingUp,
      title: "매출 증대",
      description: "고령화 시대에 맞는 새로운 수익원 창출",
    },
    {
      icon: Users,
      title: "고객 만족",
      description: "어르신들을 위한 전문 서비스로 고객 만족도 향상",
    },
    {
      icon: Award,
      title: "브랜드 가치",
      description: "사회적 가치를 실현하는 브랜드 이미지 구축",
    },
  ]

  const partnerTypes = [
    {
      title: "요양원/요양병원",
      description: "어르신들의 건강 관리를 위한 운동기구 도입",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      title: "피트니스센터",
      description: "시니어 전용 운동 프로그램 운영",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      title: "복지관/경로당",
      description: "지역 어르신들을 위한 건강 증진 프로그램",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      title: "의료기관",
      description: "재활 치료 및 예방 운동을 위한 전문 장비",
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  if (formSubmitted) {
    return (
      <div className="min-h-screen bg-white flex items-center justify-center">
        <Card className="w-full max-w-md text-center">
          <CardContent className="p-8">
            <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-4">제휴 문의 완료</h2>
            <p className="text-gray-600 mb-6">
              B2B 제휴 문의가 완료되었습니다.
              <br />
              담당자가 3일 내에 연락드리겠습니다.
            </p>
            <Link href="/">
              <Button className="w-full">홈으로 돌아가기</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            <Link href="/" className="flex items-center">
              <Image src="/images/logo.jpg" alt="이노브로텍 로고" width={40} height={40} className="mr-3" />
              <h1 className="text-2xl font-bold text-gray-900">(주)이노브로텍</h1>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h1 className="text-5xl font-bold mb-6">B2B 제휴</h1>
          <p className="text-xl leading-relaxed mb-8">
            (주)이노브로텍과 함께 고령화 시대의 새로운 비즈니스 기회를 만들어보세요
          </p>
          <Button size="lg" variant="secondary" className="text-lg px-8 py-4 h-auto">
            <Handshake className="mr-2 h-5 w-5" />
            제휴 문의하기
          </Button>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">(주)이노브로텍 제휴의 장점</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="text-center p-6">
                <CardContent className="pt-6">
                  <benefit.icon className="h-16 w-16 text-blue-600 mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-3">{benefit.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Partner Types */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">제휴 대상</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {partnerTypes.map((partner, index) => (
              <Card key={index} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="aspect-[3/2] relative">
                  <Image src={partner.image || "/placeholder.svg"} alt={partner.title} fill className="object-cover" />
                </div>
                <CardHeader>
                  <CardTitle className="text-lg">{partner.title}</CardTitle>
                  <CardDescription>{partner.description}</CardDescription>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Partnership Process */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">제휴 프로세스</h2>
          <div className="grid md:grid-cols-4 gap-8">
            {[
              { step: "01", title: "문의 접수", description: "온라인 또는 전화로 제휴 문의" },
              { step: "02", title: "상담 진행", description: "담당자와 제휴 조건 및 방향 논의" },
              { step: "03", title: "계약 체결", description: "상호 합의 하에 제휴 계약 체결" },
              { step: "04", title: "사업 시작", description: "제품 공급 및 마케팅 지원 시작" },
            ].map((process, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-blue-600 text-white rounded-full flex items-center justify-center text-xl font-bold mx-auto mb-4">
                  {process.step}
                </div>
                <h3 className="text-lg font-semibold mb-2">{process.title}</h3>
                <p className="text-gray-600">{process.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Partnership Form */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4">
          <Card>
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">B2B 제휴 문의</CardTitle>
              <CardDescription>제휴에 관심이 있으시면 아래 양식을 작성해주세요</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Company Info */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold flex items-center">
                    <Building className="h-5 w-5 mr-2" />
                    기업 정보
                  </h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="company-name">회사명 *</Label>
                      <Input
                        id="company-name"
                        required
                        placeholder="(주)시니어케어"
                        value={formData.company_name}
                        onChange={(e) => setFormData({ ...formData, company_name: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="business-type">업종 *</Label>
                      <Select
                        required
                        value={formData.business_type}
                        onValueChange={(value) => setFormData({ ...formData, business_type: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="업종을 선택하세요" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="nursing-home">요양원/요양병원</SelectItem>
                          <SelectItem value="fitness">피트니스센터</SelectItem>
                          <SelectItem value="welfare">복지관/경로당</SelectItem>
                          <SelectItem value="medical">의료기관</SelectItem>
                          <SelectItem value="retail">소매업</SelectItem>
                          <SelectItem value="other">기타</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="company-size">회사 규모</Label>
                      <Select
                        value={formData.company_size}
                        onValueChange={(value) => setFormData({ ...formData, company_size: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="회사 규모를 선택하세요" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="small">소규모 (1-10명)</SelectItem>
                          <SelectItem value="medium">중규모 (11-50명)</SelectItem>
                          <SelectItem value="large">대규모 (51명 이상)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="annual-revenue">연매출</Label>
                      <Select
                        value={formData.annual_revenue}
                        onValueChange={(value) => setFormData({ ...formData, annual_revenue: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="연매출을 선택하세요" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="under-1b">10억 미만</SelectItem>
                          <SelectItem value="1b-5b">10억-50억</SelectItem>
                          <SelectItem value="5b-10b">50억-100억</SelectItem>
                          <SelectItem value="over-10b">100억 이상</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {/* Contact Person */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">담당자 정보</h3>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="contact-name">담당자명 *</Label>
                      <Input
                        id="contact-name"
                        required
                        placeholder="홍길동"
                        value={formData.contact_name}
                        onChange={(e) => setFormData({ ...formData, contact_name: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="contact-position">직책</Label>
                      <Input
                        id="contact-position"
                        placeholder="대표이사"
                        value={formData.contact_position}
                        onChange={(e) => setFormData({ ...formData, contact_position: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="contact-phone">연락처 *</Label>
                      <Input
                        id="contact-phone"
                        required
                        placeholder="010-1234-5678"
                        value={formData.contact_phone}
                        onChange={(e) => setFormData({ ...formData, contact_phone: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="contact-email">이메일 *</Label>
                      <Input
                        id="contact-email"
                        type="email"
                        required
                        placeholder="contact@company.com"
                        value={formData.contact_email}
                        onChange={(e) => setFormData({ ...formData, contact_email: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                {/* Partnership Details */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">제휴 관련 정보</h3>
                  <div>
                    <Label htmlFor="partnership-type">희망 제휴 형태</Label>
                    <Select
                      value={formData.partnership_type}
                      onValueChange={(value) => setFormData({ ...formData, partnership_type: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="제휴 형태를 선택하세요" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="distributor">총판/대리점</SelectItem>
                        <SelectItem value="retail">소매 판매</SelectItem>
                        <SelectItem value="rental">렌탈 서비스</SelectItem>
                        <SelectItem value="installation">설치 서비스</SelectItem>
                        <SelectItem value="other">기타</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="target-products">관심 제품</Label>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mt-2">
                      {[
                        "실버 워킹머신",
                        "시니어 스트레칭 체어",
                        "균형감각 트레이너",
                        "전체 제품",
                        "신제품 출시 예정",
                        "맞춤 제작",
                      ].map((product) => (
                        <div key={product} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={product}
                            className="rounded"
                            checked={formData.target_products.includes(product)}
                            onChange={(e) => handleProductChange(product, e.target.checked)}
                          />
                          <Label htmlFor={product} className="text-sm">
                            {product}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="expected-volume">예상 구매/판매량 (월)</Label>
                    <Select
                      value={formData.expected_volume}
                      onValueChange={(value) => setFormData({ ...formData, expected_volume: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="예상 물량을 선택하세요" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1-10">1-10대</SelectItem>
                        <SelectItem value="11-50">11-50대</SelectItem>
                        <SelectItem value="51-100">51-100대</SelectItem>
                        <SelectItem value="over-100">100대 이상</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Additional Info */}
                <div>
                  <Label htmlFor="additional-info">추가 문의사항</Label>
                  <Textarea
                    id="additional-info"
                    placeholder="제휴와 관련하여 궁금한 점이나 특별한 요구사항이 있으시면 적어주세요"
                    rows={4}
                    value={formData.additional_info}
                    onChange={(e) => setFormData({ ...formData, additional_info: e.target.value })}
                  />
                </div>

                <Button type="submit" className="w-full text-lg py-4 h-auto">
                  제휴 문의 제출하기
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Contact Info */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl font-bold mb-6">직접 문의하기</h2>
          <p className="text-xl mb-8">더 자세한 상담을 원하시면 언제든지 연락주세요</p>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-semibold mb-4">B2B 전용 상담</h3>
              <p className="text-lg mb-2">📞 1588-0000 (내선 2번)</p>
              <p className="text-sm opacity-90">평일 09:00 - 18:00</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-4">이메일 문의</h3>
              <p className="text-lg mb-2">📧 b2b@innovrotech.co.kr</p>
              <p className="text-sm opacity-90">24시간 접수 가능</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}
