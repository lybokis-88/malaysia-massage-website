import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

// 회사 정보 관련 함수
export async function getCompanyInfo() {
  try {
    const result = await sql`
      SELECT * FROM company_info 
      WHERE is_active = true
      ORDER BY display_order ASC, created_at ASC
    `
    return result
  } catch (error) {
    console.error("Error fetching company info:", error)
    throw error
  }
}

export async function createCompanyInfo(data: {
  section: string
  title: string
  content: string
  image_url?: string
  display_order?: number
}) {
  try {
    const result = await sql`
      INSERT INTO company_info (section, title, content, image_url, display_order)
      VALUES (${data.section}, ${data.title}, ${data.content}, 
              ${data.image_url || ""}, ${data.display_order || 0})
      RETURNING *
    `
    return result[0]
  } catch (error) {
    console.error("Error creating company info:", error)
    throw error
  }
}

export async function updateCompanyInfo(
  id: number,
  data: {
    section?: string
    title?: string
    content?: string
    image_url?: string
    display_order?: number
  },
) {
  try {
    const result = await sql`
      UPDATE company_info 
      SET section = COALESCE(${data.section}, section),
          title = COALESCE(${data.title}, title),
          content = COALESCE(${data.content}, content),
          image_url = COALESCE(${data.image_url}, image_url),
          display_order = COALESCE(${data.display_order}, display_order),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ${id}
      RETURNING *
    `
    return result[0]
  } catch (error) {
    console.error("Error updating company info:", error)
    throw error
  }
}

export async function deleteCompanyInfo(id: number) {
  try {
    await sql`UPDATE company_info SET is_active = false WHERE id = ${id}`
    return { success: true }
  } catch (error) {
    console.error("Error deleting company info:", error)
    throw error
  }
}

// 상담 신청 관련 함수
export async function getConsultationRequests() {
  try {
    const result = await sql`
      SELECT * FROM consultation_requests 
      ORDER BY created_at DESC
    `
    return result
  } catch (error) {
    console.error("Error fetching consultation requests:", error)
    throw error
  }
}

export async function createConsultationRequest(data: {
  name: string
  age?: number
  phone: string
  email?: string
  health_condition?: string
  medical_history?: string[]
  exercise_experience?: string
  exercise_goal?: string
  additional_info?: string
  contact_time?: string
}) {
  try {
    const result = await sql`
      INSERT INTO consultation_requests (
        name, age, phone, email, health_condition, medical_history,
        exercise_experience, exercise_goal, additional_info, contact_time
      )
      VALUES (
        ${data.name}, ${data.age || null}, ${data.phone}, ${data.email || ""},
        ${data.health_condition || ""}, ${data.medical_history || []},
        ${data.exercise_experience || ""}, ${data.exercise_goal || ""},
        ${data.additional_info || ""}, ${data.contact_time || ""}
      )
      RETURNING *
    `
    return result[0]
  } catch (error) {
    console.error("Error creating consultation request:", error)
    throw error
  }
}

export async function updateConsultationRequest(
  id: number,
  data: {
    status?: string
    admin_notes?: string
    contacted_at?: Date
  },
) {
  try {
    const result = await sql`
      UPDATE consultation_requests 
      SET status = COALESCE(${data.status}, status),
          admin_notes = COALESCE(${data.admin_notes}, admin_notes),
          contacted_at = COALESCE(${data.contacted_at || null}, contacted_at),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ${id}
      RETURNING *
    `
    return result[0]
  } catch (error) {
    console.error("Error updating consultation request:", error)
    throw error
  }
}

// B2B 제휴 문의 관련 함수
export async function getB2BRequests() {
  try {
    const result = await sql`
      SELECT * FROM b2b_requests 
      ORDER BY created_at DESC
    `
    return result
  } catch (error) {
    console.error("Error fetching B2B requests:", error)
    throw error
  }
}

export async function createB2BRequest(data: {
  company_name: string
  business_type?: string
  company_size?: string
  annual_revenue?: string
  contact_name: string
  contact_position?: string
  contact_phone: string
  contact_email: string
  partnership_type?: string
  target_products?: string[]
  expected_volume?: string
  additional_info?: string
}) {
  try {
    const result = await sql`
      INSERT INTO b2b_requests (
        company_name, business_type, company_size, annual_revenue,
        contact_name, contact_position, contact_phone, contact_email,
        partnership_type, target_products, expected_volume, additional_info
      )
      VALUES (
        ${data.company_name}, ${data.business_type || ""}, ${data.company_size || ""},
        ${data.annual_revenue || ""}, ${data.contact_name}, ${data.contact_position || ""},
        ${data.contact_phone}, ${data.contact_email}, ${data.partnership_type || ""},
        ${data.target_products || []}, ${data.expected_volume || ""}, ${data.additional_info || ""}
      )
      RETURNING *
    `
    return result[0]
  } catch (error) {
    console.error("Error creating B2B request:", error)
    throw error
  }
}

export async function updateB2BRequest(
  id: number,
  data: {
    status?: string
    admin_response?: string
    admin_notes?: string
    responded_at?: Date
  },
) {
  try {
    const result = await sql`
      UPDATE b2b_requests 
      SET status = COALESCE(${data.status}, status),
          admin_response = COALESCE(${data.admin_response}, admin_response),
          admin_notes = COALESCE(${data.admin_notes}, admin_notes),
          responded_at = COALESCE(${data.responded_at || null}, responded_at),
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ${id}
      RETURNING *
    `
    return result[0]
  } catch (error) {
    console.error("Error updating B2B request:", error)
    throw error
  }
}
