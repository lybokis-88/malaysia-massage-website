import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

// 이미지 관련 함수
export async function getImages() {
  try {
    const result = await sql`
    SELECT * FROM images 
    ORDER BY created_at DESC
  `
    return result
  } catch (error) {
    console.error("Error fetching images:", error)
    throw error
  }
}

export async function createImage(data: {
  section: string
  title: string
  url: string
  type: "file" | "url"
}) {
  try {
    const result = await sql`
    INSERT INTO images (section, title, url, type)
    VALUES (${data.section}, ${data.title}, ${data.url}, ${data.type})
    RETURNING *
  `
    return result[0]
  } catch (error) {
    console.error("Error creating image:", error)
    throw error
  }
}

export async function updateImage(
  id: number,
  data: {
    section?: string
    title?: string
    url?: string
    type?: "file" | "url"
  },
) {
  try {
    const result = await sql`
    UPDATE images 
    SET section = COALESCE(${data.section}, section),
        title = COALESCE(${data.title}, title),
        url = COALESCE(${data.url}, url),
        type = COALESCE(${data.type}, type),
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ${id}
    RETURNING *
  `
    return result[0]
  } catch (error) {
    console.error("Error updating image:", error)
    throw error
  }
}

export async function deleteImage(id: number) {
  try {
    await sql`DELETE FROM images WHERE id = ${id}`
    return { success: true }
  } catch (error) {
    console.error("Error deleting image:", error)
    throw error
  }
}

// 상품 관련 함수
export async function getProducts() {
  try {
    const result = await sql`
    SELECT * FROM products 
    ORDER BY created_at DESC
  `
    return result
  } catch (error) {
    console.error("Error fetching products:", error)
    throw error
  }
}

export async function updateProduct(
  id: number,
  data: {
    name?: string
    description?: string
    regular_price?: number
    sale_price?: number
    discount_rate?: number
    features?: string[]
    detail_page_url?: string
    image_url?: string
  },
) {
  try {
    const result = await sql`
    UPDATE products 
    SET name = COALESCE(${data.name}, name),
        description = COALESCE(${data.description}, description),
        regular_price = COALESCE(${data.regular_price}, regular_price),
        sale_price = COALESCE(${data.sale_price}, sale_price),
        discount_rate = COALESCE(${data.discount_rate}, discount_rate),
        features = COALESCE(${data.features}, features),
        detail_page_url = COALESCE(${data.detail_page_url}, detail_page_url),
        image_url = COALESCE(${data.image_url}, image_url),
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ${id}
    RETURNING *
  `
    return result[0]
  } catch (error) {
    console.error("Error updating product:", error)
    throw error
  }
}

// 고객 관련 함수
export async function getCustomers() {
  try {
    const result = await sql`
    SELECT c.*, 
           COUNT(o.id) as order_count,
           SUM(o.total_amount) as total_spent
    FROM customers c
    LEFT JOIN orders o ON c.id = o.customer_id
    GROUP BY c.id
    ORDER BY c.created_at DESC
  `
    return result
  } catch (error) {
    console.error("Error fetching customers:", error)
    throw error
  }
}

export async function updateCustomer(
  id: number,
  data: {
    name?: string
    phone1?: string
    phone2?: string
    address?: string
    memo?: string
  },
) {
  try {
    const result = await sql`
    UPDATE customers 
    SET name = COALESCE(${data.name}, name),
        phone1 = COALESCE(${data.phone1}, phone1),
        phone2 = COALESCE(${data.phone2}, phone2),
        address = COALESCE(${data.address}, address),
        memo = COALESCE(${data.memo}, memo),
        updated_at = CURRENT_TIMESTAMP
    WHERE id = ${id}
    RETURNING *
  `
    return result[0]
  } catch (error) {
    console.error("Error updating customer:", error)
    throw error
  }
}

// 주문 관련 함수
export async function getOrders() {
  try {
    const result = await sql`
    SELECT o.*, 
           c.name as customer_name,
           c.phone1 as customer_phone,
           p.name as product_name
    FROM orders o
    JOIN customers c ON o.customer_id = c.id
    JOIN products p ON o.product_id = p.id
    ORDER BY o.order_date DESC
  `
    return result
  } catch (error) {
    console.error("Error fetching orders:", error)
    throw error
  }
}

export async function updateOrderStatus(id: number, status: string) {
  try {
    const result = await sql`
    UPDATE orders 
    SET status = ${status}
    WHERE id = ${id}
    RETURNING *
  `
    return result[0]
  } catch (error) {
    console.error("Error updating order status:", error)
    throw error
  }
}

export async function getOrderStats() {
  try {
    const result = await sql`
    SELECT 
      COUNT(*) as total_orders,
      SUM(total_amount) as total_revenue,
      COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending_orders,
      COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing_orders,
      COUNT(CASE WHEN status = 'shipped' THEN 1 END) as shipped_orders,
      COUNT(CASE WHEN status = 'delivered' THEN 1 END) as delivered_orders
    FROM orders
  `
    return result[0]
  } catch (error) {
    console.error("Error fetching order stats:", error)
    throw error
  }
}

// 푸터 정보 관련 함수
export async function getFooterInfo() {
  try {
    const result = await sql`
    SELECT * FROM footer_info 
    ORDER BY updated_at DESC 
    LIMIT 1
  `
    return result[0]
  } catch (error) {
    console.error("Error fetching footer info:", error)
    throw error
  }
}

export async function updateFooterInfo(data: {
  company_name: string
  phone: string
  email: string
  address: string
  website: string
}) {
  try {
    const result = await sql`
    UPDATE footer_info 
    SET company_name = ${data.company_name},
        phone = ${data.phone},
        email = ${data.email},
        address = ${data.address},
        website = ${data.website},
        updated_at = CURRENT_TIMESTAMP
    WHERE id = 1
    RETURNING *
  `
    return result[0]
  } catch (error) {
    console.error("Error updating footer info:", error)
    throw error
  }
}

// Re-export to satisfy modules that import from "@/lib/database"
export { getOrderById } from "./payment"
