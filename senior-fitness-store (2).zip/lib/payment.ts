import { neon } from "@neondatabase/serverless"

const sql = neon(process.env.DATABASE_URL!)

// 주문 생성
export async function createOrder(orderData: {
  customer_id?: number
  product_id: number
  quantity: number
  total_amount: number
  payment_method: string
  customer_info?: {
    name: string
    phone1: string
    phone2?: string
    address: string
    email?: string
  }
  shipping_info: {
    recipient_name: string
    recipient_phone: string
    address: string
    detailed_address?: string
    postal_code?: string
    delivery_request?: string
  }
}) {
  try {
    // 트랜잭션 시작
    let customer_id = orderData.customer_id

    // 고객 정보가 없으면 새로 생성
    if (!customer_id && orderData.customer_info) {
      const customerResult = await sql`
        INSERT INTO customers (name, phone1, phone2, address)
        VALUES (${orderData.customer_info.name}, ${orderData.customer_info.phone1}, 
                ${orderData.customer_info.phone2 || ""}, ${orderData.customer_info.address})
        RETURNING id
      `
      customer_id = customerResult[0].id
    }

    // 주문 생성
    const orderResult = await sql`
      INSERT INTO orders (customer_id, product_id, quantity, total_amount, payment_method, status)
      VALUES (${customer_id}, ${orderData.product_id}, ${orderData.quantity}, 
              ${orderData.total_amount}, ${orderData.payment_method}, 'pending')
      RETURNING *
    `

    const order = orderResult[0]

    // 배송 정보 저장
    await sql`
      INSERT INTO shipping_info (order_id, recipient_name, recipient_phone, address, 
                                detailed_address, postal_code, delivery_request)
      VALUES (${order.id}, ${orderData.shipping_info.recipient_name}, 
              ${orderData.shipping_info.recipient_phone}, ${orderData.shipping_info.address},
              ${orderData.shipping_info.detailed_address || ""}, 
              ${orderData.shipping_info.postal_code || ""}, 
              ${orderData.shipping_info.delivery_request || ""})
    `

    return order
  } catch (error) {
    console.error("Error creating order:", error)
    throw error
  }
}

// 결제 정보 저장
export async function createPayment(paymentData: {
  order_id: number
  payment_method: string
  payment_provider?: string
  payment_key?: string
  amount: number
}) {
  try {
    const result = await sql`
      INSERT INTO payments (order_id, payment_method, payment_provider, payment_key, amount, status)
      VALUES (${paymentData.order_id}, ${paymentData.payment_method}, 
              ${paymentData.payment_provider || ""}, ${paymentData.payment_key || ""}, 
              ${paymentData.amount}, 'pending')
      RETURNING *
    `
    return result[0]
  } catch (error) {
    console.error("Error creating payment:", error)
    throw error
  }
}

// 결제 상태 업데이트
export async function updatePaymentStatus(
  payment_id: number,
  status: string,
  payment_key?: string,
  failed_reason?: string,
) {
  try {
    const result = await sql`
      UPDATE payments 
      SET status = ${status},
          payment_key = COALESCE(${payment_key}, payment_key),
          failed_reason = ${failed_reason || null},
          paid_at = CASE WHEN ${status} = 'completed' THEN CURRENT_TIMESTAMP ELSE paid_at END,
          updated_at = CURRENT_TIMESTAMP
      WHERE id = ${payment_id}
      RETURNING *
    `

    // 결제 완료시 주문 상태도 업데이트
    if (status === "completed") {
      await sql`
        UPDATE orders 
        SET status = 'processing', payment_status = 'completed'
        WHERE id = (SELECT order_id FROM payments WHERE id = ${payment_id})
      `
    }

    return result[0]
  } catch (error) {
    console.error("Error updating payment status:", error)
    throw error
  }
}

// 주문 조회
export async function getOrderById(order_id: number) {
  try {
    const result = await sql`
      SELECT o.*, 
             c.name as customer_name, c.phone1 as customer_phone, c.address as customer_address,
             p.name as product_name, p.sale_price as product_price,
             s.recipient_name, s.recipient_phone, s.address as shipping_address,
             s.detailed_address, s.postal_code, s.delivery_request,
             pay.status as payment_status, pay.payment_method, pay.payment_key
      FROM orders o
      LEFT JOIN customers c ON o.customer_id = c.id
      LEFT JOIN products p ON o.product_id = p.id
      LEFT JOIN shipping_info s ON o.id = s.order_id
      LEFT JOIN payments pay ON o.id = pay.order_id
      WHERE o.id = ${order_id}
    `
    return result[0]
  } catch (error) {
    console.error("Error fetching order:", error)
    throw error
  }
}
