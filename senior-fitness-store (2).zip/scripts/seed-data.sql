-- 초기 데이터 삽입

-- 이미지 데이터
INSERT INTO images (section, title, url, type) VALUES
('hero', '메인 히어로 이미지', '/images/hero.jpg', 'file'),
('couple', '행복한 노부부', '/images/happy-korean-elderly-couple.png', 'file'),
('product1', '효도88 시즌1', '/placeholder.svg?height=300&width=400', 'url'),
('product2', '효도88 시즌2', '/placeholder.svg?height=300&width=400', 'url'),
('product3', '케어88 상하지 운동기구', '/placeholder.svg?height=300&width=400', 'url');

-- 상품 데이터
INSERT INTO products (name, description, regular_price, sale_price, discount_rate, features, image_url) VALUES
('효도88 시즌1', '저강도 운동으로 안전하게 걷기 운동을 할 수 있는 워킹머신', 349000, 299000, 14, ARRAY['안전 손잡이', '속도 조절', '심박수 측정'], '/placeholder.svg?height=300&width=400'),
('효도88 시즌2', '앉아서 편안하게 전신 스트레칭이 가능한 전용 의자', 229000, 189000, 17, ARRAY['등받이 조절', '팔걸이 스트레칭', '발목 운동'], '/placeholder.svg?height=300&width=400'),
('케어88 상하지 운동기구', '균형감각 향상과 낙상 예방을 위한 안전한 운동기구', 179000, 149000, 17, ARRAY['안전 바', '미끄럼 방지', '단계별 훈련'], '/placeholder.svg?height=300&width=400');

-- 고객 데이터
INSERT INTO customers (name, phone1, phone2, address, memo) VALUES
('김철수', '010-1234-5678', '02-123-4567', '서울시 강남구 테헤란로 123', '설치 희망일: 2024-01-20'),
('박영희', '010-9876-5432', '', '부산시 해운대구 센텀로 456', '오후 배송 희망'),
('이민수', '010-5555-6666', '031-777-8888', '경기도 성남시 분당구 정자로 789', '주말 배송 가능'),
('최순자', '010-1111-2222', '', '대구시 수성구 동대구로 321', '1층 거주, 계단 없음');

-- 주문 데이터
INSERT INTO orders (customer_id, product_id, quantity, total_amount, status, payment_method, payment_status) VALUES
(1, 1, 1, 299000, 'processing', 'card', 'completed'),
(2, 3, 1, 149000, 'shipped', 'bank_transfer', 'completed'),
(3, 2, 1, 189000, 'pending', 'card', 'pending'),
(4, 1, 1, 299000, 'delivered', 'phone_payment', 'completed');

-- 푸터 정보
INSERT INTO footer_info (company_name, phone, email, address, website) VALUES
('(주)이노브로텍', '1588-0000', 'info@innovrotech.co.kr', '서울시 강남구', 'www.innovrotech.co.kr');
