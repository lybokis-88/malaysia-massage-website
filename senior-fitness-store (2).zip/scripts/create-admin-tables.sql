-- 관리자 페이지 추가 테이블들

-- 회사 소개 정보 테이블
CREATE TABLE IF NOT EXISTS company_info (
    id SERIAL PRIMARY KEY,
    section VARCHAR(50) NOT NULL, -- 'about', 'mission', 'vision', 'values' 등
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    image_url TEXT,
    display_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 무료 상담 신청자 테이블
CREATE TABLE IF NOT EXISTS consultation_requests (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INTEGER,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(255),
    health_condition VARCHAR(50),
    medical_history TEXT[],
    exercise_experience VARCHAR(50),
    exercise_goal VARCHAR(50),
    additional_info TEXT,
    contact_time VARCHAR(50),
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'contacted', 'completed', 'cancelled')),
    admin_notes TEXT,
    contacted_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- B2B 제휴 문의 테이블
CREATE TABLE IF NOT EXISTS b2b_requests (
    id SERIAL PRIMARY KEY,
    company_name VARCHAR(255) NOT NULL,
    business_type VARCHAR(100),
    company_size VARCHAR(50),
    annual_revenue VARCHAR(50),
    contact_name VARCHAR(100) NOT NULL,
    contact_position VARCHAR(100),
    contact_phone VARCHAR(20) NOT NULL,
    contact_email VARCHAR(255) NOT NULL,
    partnership_type VARCHAR(100),
    target_products TEXT[],
    expected_volume VARCHAR(50),
    additional_info TEXT,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'reviewing', 'approved', 'rejected')),
    admin_response TEXT,
    admin_notes TEXT,
    responded_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 인덱스 생성
CREATE INDEX IF NOT EXISTS idx_company_info_section ON company_info(section);
CREATE INDEX IF NOT EXISTS idx_consultation_status ON consultation_requests(status);
CREATE INDEX IF NOT EXISTS idx_consultation_created ON consultation_requests(created_at);
CREATE INDEX IF NOT EXISTS idx_b2b_status ON b2b_requests(status);
CREATE INDEX IF NOT EXISTS idx_b2b_created ON b2b_requests(created_at);

-- 초기 회사 소개 데이터
INSERT INTO company_info (section, title, content, display_order) VALUES
('about', '회사 개요', '2020년, 고령화 사회에서 어르신들의 건강한 노후를 위해 시작된 (주)이노브로텍은 60세 이상 어르신들을 위한 전용 운동기구를 개발하고 있습니다.', 1),
('mission', '미션', '어르신들이 안전하고 즐겁게 운동할 수 있는 환경을 조성하여 건강한 노후 생활을 지원합니다.', 2),
('vision', '비전', '시니어 헬스케어 분야의 선도기업으로서 모든 어르신들이 활기찬 노후를 보낼 수 있도록 돕겠습니다.', 3),
('values', '핵심 가치', '안전성, 전문성, 신뢰성을 바탕으로 고객 중심의 서비스를 제공합니다.', 4);
